
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""SteelProBench Fusion V3 - deterministic, fully automatic JSONL fusion.

Only the three existing flat-model JSONL streams are required. No DOI source
text, evidence spans, manual confirmation, or model weights.

For each DOI:
  - align candidates using explicit material identity and compatible process;
  - merge non-conflicting composition/properties across models;
  - in numeric disagreements choose a STRICT 2-of-3 consensus, if present;
  - otherwise set the disputed field to null (automatic abstention);
  - merge compatible structured process steps and parameters;
  - emit flat final FUSION candidates directly for Stage 3;
  - compute a model-support confidence score for dedup ranking.

Fusion confidence is an agreement/support index, NOT a calibrated probability
of correctness and NOT a claim of agreement with original publications.

本次修改（相对原始版本）:
  1. 取消命令行参数：所有路径改为下方「用户配置区」中以绝对路径填写的配置项。
  2. 融合输出不再分片：每个输出类别只写一个完整文件（fused.jsonl 等）。
  3. 不再输出 fusion_log 文件：逐条审计日志只在内存中用于统计，不落盘。
"""
from __future__ import annotations

import hashlib
import json
import math
import os
import re
import tempfile
import unicodedata
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Optional


# ============================================================================
# =========================  用户配置区（请填写绝对路径）  ======================
# ============================================================================
# 以下四项必须填写为「绝对路径」，且不能保留占位示例值。
QWEN_DIR   = rf"C:\Users\Administrator.DESKTOP-FHP5JRG\Desktop\论文\SteelProBench__A_large_scale_benchmark_dataset_for_AI_driven_steel_design (1)\data\qwen"    # qwen3_32b 结果目录的绝对路径
GEMMA_DIR  = rf"C:\Users\Administrator.DESKTOP-FHP5JRG\Desktop\论文\SteelProBench__A_large_scale_benchmark_dataset_for_AI_driven_steel_design (1)\data\gemma"   # gemma3_27b 结果目录的绝对路径
GPTOSS_DIR = rf"C:\Users\Administrator.DESKTOP-FHP5JRG\Desktop\论文\SteelProBench__A_large_scale_benchmark_dataset_for_AI_driven_steel_design (1)\data\gptoss"   # gptoss_20b 结果目录的绝对路径
OUTPUT_DIR = rf"C:\Users\Administrator.DESKTOP-FHP5JRG\Desktop\论文\SteelProBench__A_large_scale_benchmark_dataset_for_AI_driven_steel_design (1)\data\fusion"        # 融合结果输出目录的绝对路径

# 其余可调参数（同样在代码中配置，不再通过命令行传入）
PRECISION    = 6          # 数值保留小数位（0~15）
MIN_ELEMENTS = 2          # 最少有效元素数（0~36）
RECURSIVE    = False      # 是否递归读取输入子目录
DOI_POLICY   = "union"    # "union"(并集) 或 "intersection"(交集)
# ============================================================================
# =======================  用户配置区结束（以下无需改动）  ======================
# ============================================================================


MODEL_NAMES = ("qwen3_32b", "gemma3_27b", "gptoss_20b")
ELEMENTS = (
    "H", "B", "C", "N", "O", "F", "Na", "Mg", "Al", "Si", "P",
    "S", "Cl", "Ca", "Ti", "V", "Cr", "Mn", "Fe", "Co", "Ni",
    "Cu", "Zn", "As", "Y", "Zr", "Nb", "Mo", "Sn", "Sb", "La",
    "Ce", "Ta", "W", "Pb", "Bi",
)
PROPERTIES = ("tensile_strength", "yield_strength", "elongation")
UNITS = ("tensile_unit", "yield_unit", "elongation_unit")
FIELDS = (
    "doi", "material_name", "tensile_strength", "tensile_unit",
    "yield_strength", "yield_unit", "elongation", "elongation_unit",
    *ELEMENTS, "classification", "process_description",
    "process_structured_summary",
)
STR_UNITS = {
    "mpa": 1.0, "gpa": 1000.0, "kpa": .001, "pa": 1e-6,
    "n/mm2": 1.0, "n/mm^2": 1.0, "ksi": 6.894757293168,
}
EL_UNITS = {
    "%": 1.0, "percent": 1.0, "percentage": 1.0,
    "pct": 1.0, "fraction": 100.0, "ratio": 100.0,
}
SIMPLE_NUMBER = re.compile(r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?\Z")
PARAM_PATTERN = re.compile(
    r"^\s*([-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?)\s*"
    r"(um|mm|cm|m|h|hr|hrs|min|mins|s|sec|secs|w|kw|mpa|gpa|"
    r"mm/s|um/s|mm/min|°c|c|k|%)\s*$", re.I
)


def compact(value: Any) -> str:
    s = unicodedata.normalize("NFKC", str(value or "")).casefold()
    return re.sub(r"\s+", " ", s).strip()


def name_key(name: Any) -> str:
    """Normalize common steel aliases without deleting experimental conditions.

    Material label token order is ignored. Processing step order is matched
    separately and NEVER sorted.
    """
    s = compact(name)
    s = re.sub(r"\bselective[\s-]+laser[\s-]+melting\b", "slm", s)
    s = re.sub(r"\bas[\s-]+built\b", "asbuilt", s)
    s = re.sub(r"\b(?:ss|aisi)[\s-]*(\d{3,4}[a-z]?)\b", r"\1", s)
    s = re.sub(r"\bstainless[\s-]+steel\b", "steel", s)
    tokens = re.findall(r"[a-z0-9]+", s)
    tokens = [t for t in tokens if t not in {"steel", "grade", "specimen", "sample"}]
    return "|".join(sorted(tokens))


def doi_key(doi: str) -> str:
    s = doi.strip()
    s = re.sub(r"^https?://(?:dx\.)?doi\.org/", "", s, flags=re.I)
    s = re.sub(r"^doi:\s*", "", s, flags=re.I)
    return s.strip().lower()


def number(value: Any) -> Optional[float]:
    if value is None or isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        x = float(value)
    elif isinstance(value, str) and SIMPLE_NUMBER.fullmatch(
            value.strip().replace(",", "")):
        x = float(value.strip().replace(",", ""))
    else:
        return None
    return x if math.isfinite(x) else None


def empty_record(doi: str) -> dict:
    result = {field: None for field in FIELDS}
    result["doi"] = doi
    result["classification"] = "Unknown"
    result["process_structured_summary"] = []
    return result


def canonical_operation(raw: Any) -> str:
    s = compact(raw)
    aliases = {
        "selective laser melting": "slm printing",
        "slm": "slm printing",
        "selective laser melting printing": "slm printing",
        "water quench": "water quenching",
        "quenching in water": "water quenching",
    }
    return aliases.get(s, s)


def normalized_parameter(raw: Any) -> str:
    """Used ONLY for equivalence comparison; original strings are retained."""
    if raw is None:
        return ""
    if isinstance(raw, (int, float)):
        n = number(raw)
        return str(round(n, 8)) if n is not None else ""
    s = compact(raw).replace("μ", "u").replace("µ", "u")
    s = re.sub(r"\s+", " ", s)
    m = PARAM_PATTERN.fullmatch(s)
    if not m:
        return s.replace(" ", "")
    val, unit = float(m.group(1)), m.group(2).lower()
    if unit in ("h", "hr", "hrs"):
        val *= 60
        unit = "min"
    elif unit in ("s", "sec", "secs"):
        val /= 60
        unit = "min"
    elif unit == "mins":
        unit = "min"
    elif unit == "mm":
        val *= 1000
        unit = "um"
    elif unit == "cm":
        val *= 10000
        unit = "um"
    elif unit == "kw":
        val *= 1000
        unit = "w"
    elif unit == "gpa":
        val *= 1000
        unit = "mpa"
    elif unit == "c":
        unit = "°c"
    return f"{round(val, 8):g}{unit}"


def steps_of(row: dict) -> list[dict]:
    """Original normalized step dictionaries; no inferred steps are generated."""
    steps = row.get("process_structured_summary") or []
    return sorted(steps, key=lambda s: (s["order"], s["_seq"]))


def operation_sequence(row: dict) -> tuple[str, ...]:
    return tuple(canonical_operation(s["detail"].get("operation"))
                 for s in steps_of(row))


def step_parameter_map(step: dict) -> dict[str, str]:
    return {compact(k): normalized_parameter(v)
            for k, v in step["detail"].items()
            if k != "operation" and v not in (None, "")}


def check_process(a: dict, b: dict) -> tuple[bool, int, str]:
    """Hard-exclude contradictory processing; do NOT use tensile values as IDs."""
    sa, sb = steps_of(a), steps_of(b)
    if sa and sb:
        oa, ob = operation_sequence(a), operation_sequence(b)
        if len(set(oa)) != len(oa) or len(set(ob)) != len(ob):
            if oa != ob:
                return False, -1, "repeated_operation_sequence_differs"
            for left, right in zip(sa, sb):
                pa, pb = step_parameter_map(left), step_parameter_map(right)
                if any(pa[key] != pb[key] for key in pa.keys() & pb.keys()):
                    return False, -1, "repeated_operation_parameter_conflict"
            return True, 2, "matching_repeated_operation_sequence"
        shared = set(oa) & set(ob)
        if not shared:
            return False, -1, "no_common_process_operation"
        for op in shared:
            pa = step_parameter_map(sa[oa.index(op)])
            pb = step_parameter_map(sb[ob.index(op)])
            if any(pa[k] != pb[k] for k in pa.keys() & pb.keys()):
                return False, -1, "conflicting_process_parameters"
        common_a = [x for x in oa if x in shared]
        common_b = [x for x in ob if x in shared]
        if common_a != common_b:
            return False, -1, "conflicting_process_order"
        if oa == ob:
            return True, 4, "same_process_operations"
        if all(x in ob for x in oa) or all(x in oa for x in ob):
            return True, 3, "compatible_partial_process"
        return True, 1, "partially_overlapping_process"
    da = compact(a.get("process_description"))
    db = compact(b.get("process_description"))
    if not sa and not sb and da and db:
        return (True, 2, "same_description") if da == db else (
            False, -1, "different_unstructured_process_descriptions"
        )
    return True, 0, "limited_process_evidence"


def normalize_row(raw: dict, doi: str, precision: int) -> tuple[dict, list[str]]:
    row = empty_record(doi)
    flags = []
    if not isinstance(raw, dict):
        return row, ["not_an_object"]
    name = raw.get("material_name")
    if isinstance(name, str) and name.strip():
        row["material_name"] = name.strip()
    else:
        flags.append("missing_material_identity")
    cl = raw.get("classification")
    if isinstance(cl, str) and cl.strip():
        row["classification"] = cl.strip()

    for prop, unit in zip(PROPERTIES, UNITS):
        val = raw.get(prop)
        if val is None or val == "":
            if raw.get(unit) not in (None, ""):
                flags.append(f"{prop}:orphan_unit")
            continue
        num = number(val)
        if num is None:
            flags.append(f"{prop}:invalid_value")
            continue
        u = compact(raw.get(unit)).replace(" ", "")
        factor = EL_UNITS.get(u) if prop == "elongation" else STR_UNITS.get(u)
        if factor is None:
            flags.append(f"{prop}:unknown_unit")
            continue
        num *= factor
        in_range = (0 <= num <= 100) if prop == "elongation" else (0 < num <= 10000)
        if not in_range:
            flags.append(f"{prop}:invalid_range")
            continue
        row[prop] = round(num, precision)
        row[unit] = "%" if prop == "elongation" else "MPa"

    for el in ELEMENTS:
        val = raw.get(el)
        if val in (None, ""):
            continue
        num = number(val)
        if num is None or not 0 <= num <= 100:
            flags.append(f"{el}:invalid_composition")
        else:
            row[el] = round(num, precision)

    desc = raw.get("process_description")
    if isinstance(desc, str) and desc.strip():
        row["process_description"] = desc.strip()
    elif desc not in (None, ""):
        flags.append("process_description:invalid_type")

    raw_steps = raw.get("process_structured_summary")
    if isinstance(raw_steps, list):
        converted = []
        for seq, s in enumerate(raw_steps):
            if not isinstance(s, dict) or not isinstance(s.get("detail"), dict):
                flags.append(f"process_step_{seq}:invalid_schema")
                continue
            order = s.get("order")
            if not isinstance(order, int) or isinstance(order, bool) or order < 1:
                flags.append(f"process_step_{seq}:invalid_order")
                order = seq + 1
            detail = dict(s["detail"])
            if not canonical_operation(detail.get("operation")):
                flags.append(f"process_step_{seq}:missing_operation")
                continue
            converted.append({
                "order": order,
                "_seq": seq,
                "detail": detail,
                "text": str(s.get("text") or "").strip(),
            })
        row["process_structured_summary"] = converted
    elif raw_steps not in (None, ""):
        flags.append("process_structured_summary:invalid_type")
    return row, flags


def candidate_compatible(a: dict, b: dict) -> tuple[bool, int, str]:
    """Conservative cross-model state matching, never on identical YS/UTS/EL alone."""
    ka, kb = name_key(a.get("material_name")), name_key(b.get("material_name"))
    if not ka or ka != kb:
        return False, -1, "material_name_mismatch"

    process_ok, process_score, process_reason = check_process(a, b)
    if not process_ok:
        return False, -1, process_reason

    # Composition contradictions can indicate different states under the same
    # grade label. Permit one mismatched field (possible extraction mistake).
    overlap = [(el, a[el], b[el]) for el in ELEMENTS
               if a.get(el) is not None and b.get(el) is not None]
    compatible = 0
    conflicts = 0
    for element, av, bv in overlap:
        tolerance = max(0.02 if element != "Fe" else 0.5,
                        max(abs(av), abs(bv)) * 0.02)
        if abs(av - bv) <= tolerance:
            compatible += 1
        else:
            conflicts += 1
    if conflicts > 1 and conflicts * 3 >= max(len(overlap), 1):
        return False, -1, "multiple_composition_disagreements"

    shared_properties = sum(
        a.get(p) is not None and b.get(p) is not None and
        abs(a[p] - b[p]) <= 10**-6
        for p in PROPERTIES
    )
    # If process identity is unknown for one model, matching on grade name
    # alone is unsafe. Demand substantial shared experimental information.
    if process_score == 0 and compatible < 2 and shared_properties == 0:
        return False, -1, "insufficient_state_identity"
    return True, process_score + min(compatible, 5) + shared_properties, process_reason


def cross_model_groups(items: list[dict]) -> tuple[list[list[dict]], dict[int, list[str]]]:
    """Conservative graph matching, with one candidate per model in each group.

    If one row could join TWO rows from another model, we suppress those edges.
    This avoids attaching an unspecified condition to one of multiple states.
    """
    n = len(items)
    eligible_edges = []
    neighbor = defaultdict(set)
    messages = defaultdict(list)
    for i in range(n):
        for j in range(i + 1, n):
            if items[i]["model_idx"] == items[j]["model_idx"]:
                continue
            ok, score, reason = candidate_compatible(items[i]["row"], items[j]["row"])
            if ok:
                eligible_edges.append((score, i, j, reason))
                neighbor[(i, items[j]["model_idx"])].add(j)
                neighbor[(j, items[i]["model_idx"])].add(i)
            elif (name_key(items[i]["row"].get("material_name")) and
                  name_key(items[i]["row"].get("material_name")) ==
                  name_key(items[j]["row"].get("material_name"))):
                messages[i].append("separate_states_or_conflicting_process")
                messages[j].append("separate_states_or_conflicting_process")

    ambiguous = {key for key, options in neighbor.items() if len(options) > 1}
    parent = list(range(n))
    members = {i: {i} for i in range(n)}

    def root(i: int) -> int:
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    for score, i, j, reason in sorted(
            eligible_edges, key=lambda e: (-e[0], e[1], e[2])):
        if ((i, items[j]["model_idx"]) in ambiguous or
                (j, items[i]["model_idx"]) in ambiguous):
            messages[i].append("ambiguous_one_to_many_alignment")
            messages[j].append("ambiguous_one_to_many_alignment")
            continue
        ri, rj = root(i), root(j)
        if ri == rj:
            continue
        im = members[ri]
        jm = members[rj]
        if {items[k]["model_idx"] for k in im} & {
                items[k]["model_idx"] for k in jm}:
            messages[i].append("same_model_collision")
            messages[j].append("same_model_collision")
            continue
        # Require the proposed combined component to be pairwise compatible,
        # avoiding transitive merges of different material states.
        if any(not candidate_compatible(items[a]["row"], items[b]["row"])[0]
               for a in im for b in jm):
            messages[i].append("transitive_alignment_conflict")
            messages[j].append("transitive_alignment_conflict")
            continue
        if score == 0:
            messages[i].append("weak_alignment_without_shared_process")
            messages[j].append("weak_alignment_without_shared_process")
        parent[rj] = ri
        members[ri].update(jm)
        del members[rj]

    groups = []
    for comp in sorted(members.values(), key=lambda x: min(x)):
        groups.append([items[i] for i in sorted(comp)])
    return groups, messages


def group_candidate_fields(group: list[dict], field: str) -> dict[float, set[str]]:
    observations = defaultdict(set)
    for item in group:
        value = item["row"].get(field)
        if value is not None:
            observations[value].add(MODEL_NAMES[item["model_idx"]])
    return observations


def choose_discrete(options: dict[Any, set[str]]
                    ) -> tuple[Optional[Any], set[str], str]:
    """Unweighted, strict distinct-model consensus, otherwise final null.

    One non-null option survives even if only one model found it.
    If candidates disagree, a winner must have at least two supporting models
    and strictly more supporters than every alternative. Otherwise abstain.
    """
    if not options:
        return None, set(), "all_missing"
    ordered = sorted(options.items(), key=lambda x: (-len(x[1]), str(x[0])))
    top_value, supporters = ordered[0]
    if len(ordered) == 1:
        return top_value, supporters, "no_conflict"
    if len(supporters) >= 2 and len(supporters) > len(ordered[1][1]):
        return top_value, supporters, "strict_majority"
    return None, set(), "automatic_null_on_tie"



def select_process(group: list[dict]) -> tuple[Optional[str], list[dict], list[dict], list[str]]:
    """Combine only existing steps and parameters; never invent a processing fact.

    Acyclic partial sequences can be merged into a single ordered sequence.
    Repeated operations or incompatible ordering fall back to the richest
    *original* model route rather than fabricating an order.
    """
    import heapq

    route_items = [x for x in group if steps_of(x["row"])]
    flags: list[str] = []
    if not route_items:
        descriptions = [(x["row"].get("process_description"), x["model_idx"])
                        for x in group if x["row"].get("process_description")]
        if not descriptions:
            return None, [], [], flags
        chosen, _ = max(descriptions, key=lambda x: (len(x[0]), -x[1]))
        supporters = {MODEL_NAMES[x["model_idx"]] for x in group
                      if compact(x["row"].get("process_description")) == compact(chosen)}
        return chosen, [], [{
            "atom": "process_description",
            "support_models": sorted(supporters),
            "support_fraction": round(len(supporters) / 3, 6),
        }], flags

    def richness(x: dict) -> tuple:
        steps = steps_of(x["row"])
        return (len(steps),
                sum(sum(v not in (None, "") for k, v in s["detail"].items()
                        if k != "operation") for s in steps),
                len(x["row"].get("process_description") or ""),
                -x["model_idx"])

    primary = max(route_items, key=richness)
    base_steps = steps_of(primary["row"])
    base_ops = operation_sequence(primary["row"])
    seqs = [operation_sequence(x["row"]) for x in route_items]

    def from_original(reason: str):
        flags.append(reason)
        atom_support = []
        for pos, s in enumerate(base_steps):
            operation = canonical_operation(s["detail"].get("operation"))
            atom_support.append({
                "atom": f"operation:{pos}:{operation}",
                "support_models": [MODEL_NAMES[primary["model_idx"]]],
                "support_fraction": round(1 / 3, 6)
            })
            for k, v in s["detail"].items():
                if k != "operation" and v not in (None, ""):
                    atom_support.append({
                        "atom": f"process:{pos}:{k}={normalized_parameter(v)}",
                        "support_models": [MODEL_NAMES[primary["model_idx"]]],
                        "support_fraction": round(1 / 3, 6)
                    })
        return (primary["row"].get("process_description"),
                [{"order": n+1, "detail": dict(s["detail"]), "text": s["text"]}
                 for n, s in enumerate(base_steps)],
                atom_support, flags)

    if any(len(ops) != len(set(ops)) for ops in seqs):
        return from_original("repeated_process_operation_kept_primary_route")

    nodes = set(op for ops in seqs for op in ops)
    edges = {op: set() for op in nodes}
    degree = {op: 0 for op in nodes}
    for ops in seqs:
        for before, after in zip(ops, ops[1:]):
            if after not in edges[before]:
                edges[before].add(after)
                degree[after] += 1

    # Keep base process order where compatible, break independent ties
    # deterministically using first-seen rank followed by lexical order.
    seen_order = {}
    for rank, op in enumerate(base_ops):
        seen_order.setdefault(op, rank)
    for seq in seqs:
        for op in seq:
            seen_order.setdefault(op, len(seen_order) + len(base_ops))
    queue = [(seen_order[op], op) for op in nodes if degree[op] == 0]
    heapq.heapify(queue)
    order = []
    while queue:
        _, op = heapq.heappop(queue)
        order.append(op)
        for nxt in sorted(edges[op]):
            degree[nxt] -= 1
            if degree[nxt] == 0:
                heapq.heappush(queue, (seen_order[nxt], nxt))
    if len(order) != len(nodes):
        return from_original("incompatible_process_order_kept_primary_route")

    # Observations are keyed by operation and parameter. Values are only
    # normalized for comparison; selected raw values remain extracted values.
    by_op = defaultdict(list)
    for x in route_items:
        for step in steps_of(x["row"]):
            op = canonical_operation(step["detail"].get("operation"))
            by_op[op].append((x["model_idx"], step))

    output_steps, atom_support = [], []
    for index, op in enumerate(order, 1):
        parts = by_op[op]
        primary_part = next((step for model, step in parts
                             if model == primary["model_idx"]), parts[0][1])
        display_op = primary_part["detail"]["operation"]
        op_support = {MODEL_NAMES[model] for model, _ in parts}
        atom_support.append({
            "atom": f"operation:{index}:{op}",
            "support_models": sorted(op_support),
            "support_fraction": round(len(op_support)/3, 6)
        })
        keys = defaultdict(lambda: defaultdict(set))
        originals = defaultdict(dict)
        for model, step in parts:
            for key, value in step["detail"].items():
                if key == "operation" or value in (None, ""):
                    continue
                canonical_key = compact(key)
                cv = normalized_parameter(value)
                keys[canonical_key][cv].add(MODEL_NAMES[model])
                originals[canonical_key].setdefault(cv, (key, value))

        detail = {"operation": display_op}
        for key, options in sorted(keys.items()):
            selected, supporters, decision = choose_discrete(options)
            if selected is None:
                flags.append(f"process_parameter_abstained:{op}:{key}")
                continue
            raw_key, raw_value = originals[key][selected]
            detail[raw_key] = raw_value
            atom_support.append({
                "atom": f"process:{index}:{op}:{key}={selected}",
                "support_models": sorted(supporters),
                "support_fraction": round(len(supporters)/3, 6),
            })
            if decision == "strict_majority":
                flags.append(f"process_parameter_majority:{op}:{key}")

        # Explicitly serialize merged structured steps instead of keeping a
        # source sentence that may contradict an automatically omitted value.
        params = [f"{k.replace('_', ' ')} {v}" for k, v in detail.items()
                  if k != "operation"]
        summary = f"{display_op}" + (f" ({', '.join(params)})" if params else "")
        output_steps.append({
            "order": index, "detail": detail, "text": summary
        })

    if tuple(order) != base_ops:
        flags.append("compatible_process_steps_complemented")

    # Preserve original natural-language process_description, which can contain
    # important details that are not present in structured steps (orientation,
    # substrate, atmosphere, etc.). Do not replace it with a lossy synthetic text.
    desc_items = [(x["row"].get("process_description"), x["model_idx"])
                  for x in group if x["row"].get("process_description")]
    description = (max(desc_items, key=lambda x: (len(x[0]), -x[1]))[0]
                   if desc_items else None)

    # Append *only new structured details* absent from the most detailed
    # source route. These are transparent model-derived additions, not quotes.
    source_ops = set(base_ops)
    addenda = []
    for step in output_steps:
        operation = canonical_operation(step["detail"]["operation"])
        if operation not in source_ops:
            addenda.append(step["text"])
        else:
            original = next(
                (x for x in base_steps if
                 canonical_operation(x["detail"].get("operation")) == operation),
                None
            )
            original_keys = set(original["detail"]) if original else set()
            new_params = [(key, value) for key, value in step["detail"].items()
                          if key != "operation" and key not in original_keys]
            if new_params:
                addenda.append(
                    f"{step['detail']['operation']} additional parameters: " +
                    ", ".join(f"{key.replace('_', ' ')} {value}"
                              for key, value in new_params)
                )
    if addenda:
        flags.append("process_description_extended_with_complementary_details")
        appendix = "Additional extracted processing details: " + "; ".join(addenda)
        description = ((description.rstrip().rstrip(".") + ". " + appendix + ".")
                       if description else appendix + ".")
    if description is None:
        description = "; then ".join(step["text"] for step in output_steps)
    return description, output_steps, atom_support, flags


def fuse_group(doi: str, group: list[dict],
               alignment_messages: list[str], precision: int,
               min_elements: int) -> tuple[dict, dict]:
    """Produce one finished Stage-3 candidate and an audit log (no review queue)."""
    fused = empty_record(doi)
    log = {
        "doi": doi,
        "fusion_method": "unweighted_conservative_field_union_v3",
        "fusion_status": "automatically_completed",
        "model_sources": {MODEL_NAMES[x["model_idx"]]: [x["record_index"]]
                          for x in group},
        "source_locations": {
            MODEL_NAMES[x["model_idx"]]: {
                "file": x["origin"].get("file"),
                "line": x["origin"].get("line"),
                "doi_record_index": x["record_index"],
            } for x in group
        },
        "number_of_models": len({x["model_idx"] for x in group}),
        "field_sources": {},
        "field_support": {},
        "field_conflicts": {},
        "automatic_decisions": {},
        "input_flags": {
            f"{MODEL_NAMES[x['model_idx']]}:{x['record_index']}": x["issues"]
            for x in group if x["issues"]
        },
        "alignment_notes": sorted(set(alignment_messages)),
        "postprocessing_diagnostics": [],
    }
    named = [x for x in group if x["row"]["material_name"]]
    if named:
        # Formatting is selected deterministically, not hallucinated.
        src = max(named, key=lambda x: (len(x["row"]["material_name"]),
                                        -x["model_idx"]))
        fused["material_name"] = src["row"]["material_name"]

    for field in (*PROPERTIES, *ELEMENTS):
        options = group_candidate_fields(group, field)
        choice, supporter_names, decision = choose_discrete(options)
        if choice is not None:
            fused[field] = round(choice, precision)
            log["field_sources"][field] = sorted(supporter_names)
            log["field_support"][field] = round(len(supporter_names)/3, 6)
        if len(options) > 1:
            log["field_conflicts"][field] = [
                {"value": value, "models": sorted(supporters)}
                for value, supporters in sorted(options.items())
            ]
        if options:
            log["automatic_decisions"][field] = decision

    for property_name, unit_name in zip(PROPERTIES, UNITS):
        if fused[property_name] is not None:
            fused[unit_name] = "%" if property_name == "elongation" else "MPa"

    class_options = defaultdict(set)
    class_display = {}
    for x in group:
        value = x["row"].get("classification")
        canonical_label = compact(value)
        if canonical_label and canonical_label != "unknown":
            class_options[canonical_label].add(MODEL_NAMES[x["model_idx"]])
            class_display.setdefault(canonical_label, value)
    cls, supporters, decision = choose_discrete(class_options)
    if cls is not None:
        fused["classification"] = class_display[cls]
        log["field_sources"]["classification"] = sorted(supporters)
    if len(class_options) > 1:
        log["field_conflicts"]["classification"] = [
            {"value": class_display[cl], "models": sorted(sources)}
            for cl, sources in sorted(class_options.items())
        ]
    log["automatic_decisions"]["classification"] = decision

    desc, steps, process_atoms, process_flags = select_process(group)
    fused["process_description"] = desc
    fused["process_structured_summary"] = steps
    log["process_atom_support"] = process_atoms
    log["process_fusion_diagnostics"] = sorted(set(process_flags))

    composition = [fused[el] for el in ELEMENTS if fused[el] is not None]
    element_count = len(composition)
    total = sum(composition)
    if total > 100.01:
        log["postprocessing_diagnostics"].append("composition_total_exceeds_100")
    if element_count < min_elements:
        log["postprocessing_diagnostics"].append("insufficient_elements")
    if any(fused[p] is None for p in PROPERTIES):
        log["postprocessing_diagnostics"].append("incomplete_tensile_properties")
    if not fused.get("process_description") and not steps:
        log["postprocessing_diagnostics"].append("missing_processing")
    if log["field_conflicts"]:
        log["postprocessing_diagnostics"].append("fusion_conflicts_auto_resolved")
    # The above are INFORMATIONAL flags for Stage 3, not calls for re-extraction,
    # checking the paper, human review, or a second fusion stage.

    q = {}
    for category, fields in (
        ("composition", ELEMENTS),
        ("properties", PROPERTIES),
    ):
        nums = [log["field_support"][f] for f in fields
                if f in log["field_support"]]
        q[category] = round(sum(nums)/len(nums), 6) if nums else None
    nums_proc = [atom["support_fraction"] for atom in process_atoms]
    q["processing"] = round(sum(nums_proc)/len(nums_proc), 6) if nums_proc else None
    valid = [v for v in q.values() if v is not None]
    fused["confidence_score"] = round(sum(valid)/len(valid), 6) if valid else 0.0

    # Completeness stays separate from cross-model agreement.
    completeness = (
        int(element_count >= min_elements)
        + sum(fused[p] is not None for p in PROPERTIES) / 3
        + int(bool(desc or steps))
    ) / 3
    log["completeness_score"] = round(completeness, 6)
    log["confidence_score"] = fused["confidence_score"]
    log["confidence_components"] = q
    log["confidence_definition"] = (
        "macro_mean_per_field_distinct_model_support_divided_by_3;"
        "not_accuracy_or_calibrated_probability"
    )
    log["known_composition_sum"] = round(total, precision)
    log["non_null_element_count"] = element_count
    log["non_null_property_count"] = sum(fused[p] is not None for p in PROPERTIES)

    # For maximum Stage-3 compatibility: output the SAME original flat schema
    # plus one confidence_score key; detailed metadata lives only in memory.
    assert set(fused) == set(FIELDS) | {"confidence_score"}
    return fused, log


def fuse_from_model_streams(doi: str, raws: list[list[dict]], *,
                            precision: int = 6, min_elements: int = 2) -> dict:
    """Backward-friendly per-DOI interface; one stream per model."""
    if len(raws) != 3:
        raise ValueError("Exactly three model streams are expected")
    items, rejected, exact_duplicates = [], [], []
    for model_idx, stream in enumerate(raws):
        seen = set()
        for j, raw in enumerate(stream):
            if not isinstance(raw, dict):
                rejected.append({"doi": doi, "model": MODEL_NAMES[model_idx],
                                 "record_index": j, "reason": "not_object"})
                continue
            row, issues = normalize_row(raw, doi, precision)
            fingerprint = json.dumps(row, ensure_ascii=False, sort_keys=True)
            if fingerprint in seen:
                exact_duplicates.append({"model": MODEL_NAMES[model_idx],
                                         "record_index": j,
                                         "reason": "identical_same_model_copy"})
                continue
            seen.add(fingerprint)
            items.append({"model_idx": model_idx, "record_index": j,
                          "row": row, "issues": issues,
                          "origin": {
                              "file": raw.get("__source_file__"),
                              "line": raw.get("__source_line__")
                          }})
    groups, alignment = cross_model_groups(items)
    fused, logs = [], []
    for group in groups:
        messages = [v for x in group for v in alignment.get(items.index(x), [])]
        record, log = fuse_group(doi, group, messages, precision, min_elements)
        fused.append(record)
        logs.append(log)
    return {
        "doi": doi,
        "fused": fused,
        "fusion_log": logs,
        "rejected": rejected,
        "removed_same_model_exact_copies": exact_duplicates,
        "source_candidate_rows": sum(map(len, raws)),
    }


def read_model_directory(folder: Path, model: str, recursive: bool = False) -> tuple[dict, dict]:
    if not folder.is_dir():
        raise FileNotFoundError(f"Missing {model} directory: {folder}")
    finder = folder.rglob if recursive else folder.glob
    paths = sorted(p for p in finder(f"model_{model}_*.jsonl") if p.is_file())
    if not paths:
        paths = sorted(p for p in finder("*.jsonl")
                       if p.is_file() and not p.name.startswith(
                           ("fused_", "fusion_log_", "rejected_", "model_errors_")))
    if not paths:
        raise FileNotFoundError(f"No input JSONL found for {model}: {folder}")
    records = defaultdict(list)
    count = 0
    for path in paths:
        with path.open(encoding="utf-8-sig") as file:
            for line_no, line in enumerate(file, 1):
                if not line.strip():
                    continue
                try:
                    raw = json.loads(line)
                except json.JSONDecodeError as exc:
                    raise ValueError(f"{path}:{line_no}: {exc}") from exc
                if not isinstance(raw, dict) or not isinstance(raw.get("doi"), str):
                    raise ValueError(f"Invalid DOI/object: {path}:{line_no}")
                doi = doi_key(raw["doi"])
                if not doi:
                    raise ValueError(f"Blank DOI: {path}:{line_no}")
                raw["doi"] = doi
                raw["__source_file__"] = str(path)
                raw["__source_line__"] = line_no
                records[doi].append(raw)
                count += 1
    return dict(records), {"files": len(paths), "records": count, "dois": len(records)}


def write_jsonl(folder: Path, name: str, rows: list[dict]) -> None:
    """将一类结果一次性写入单个完整文件（不再按 shard-size 分片）。"""
    folder.mkdir(parents=True, exist_ok=True)
    dst = folder / name
    with tempfile.NamedTemporaryFile("w", encoding="utf-8",
                                     dir=folder, delete=False,
                                     prefix=".fusion-v3-", suffix=".tmp") as f:
        temp = Path(f.name)
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False, allow_nan=False,
                               separators=(",", ":")) + "\n")
    os.replace(temp, dst)


def _validate_config() -> tuple[Path, Path, Path, Path]:
    """校验用户配置：路径必须是已填写的绝对路径。返回四个 Path。"""
    named = {
        "QWEN_DIR": QWEN_DIR,
        "GEMMA_DIR": GEMMA_DIR,
        "GPTOSS_DIR": GPTOSS_DIR,
        "OUTPUT_DIR": OUTPUT_DIR,
    }
    paths = {}
    for label, value in named.items():
        p = Path(str(value).strip())
        if not str(p):
            raise SystemExit(f"[配置错误] {label} 不能为空，请填写绝对路径。")
        if not p.is_absolute():
            raise SystemExit(f"[配置错误] {label} 必须是绝对路径，当前值：{value}")
        paths[label] = p
    if DOI_POLICY not in ("union", "intersection"):
        raise SystemExit('[配置错误] DOI_POLICY 只能是 "union" 或 "intersection"。')
    if not 0 <= PRECISION <= 15:
        raise SystemExit("[配置错误] PRECISION 必须在 0~15 之间。")
    if not 0 <= MIN_ELEMENTS <= len(ELEMENTS):
        raise SystemExit("[配置错误] MIN_ELEMENTS 无效（应在 0~36 之间）。")
    out = paths["OUTPUT_DIR"]
    folders = (paths["QWEN_DIR"], paths["GEMMA_DIR"], paths["GPTOSS_DIR"])
    if out.resolve() in {p.resolve() for p in folders}:
        raise SystemExit("[配置错误] 输出目录不能与任一输入目录相同。")
    return folders[0], folders[1], folders[2], out


def main() -> None:
    qwen_dir, gemma_dir, gptoss_dir, out = _validate_config()

    sources, stats = [], {}
    for model, folder in zip(MODEL_NAMES, (qwen_dir, gemma_dir, gptoss_dir)):
        data, counts = read_model_directory(folder, model, RECURSIVE)
        sources.append(data)
        stats[model] = counts
        print(f"[load] {model}: {counts}", flush=True)
    doi_sets = [set(d.keys()) for d in sources]
    keys = (set.union(*doi_sets) if DOI_POLICY == "union"
            else set.intersection(*doi_sets))
    fused, logs, rejected, removed = [], [], [], []
    for doi in sorted(keys):
        result = fuse_from_model_streams(
            doi, [src.get(doi, []) for src in sources],
            precision=PRECISION, min_elements=MIN_ELEMENTS)
        fused.extend(result["fused"])
        logs.extend(result["fusion_log"])
        rejected.extend(result["rejected"])
        for duplicate in result["removed_same_model_exact_copies"]:
            removed.append({"doi": doi, **duplicate})

    # 输出（不分片、不落盘 fusion_log）：每个类别只写一个完整文件。
    out.mkdir(parents=True, exist_ok=True)
    write_jsonl(out, "fused.jsonl", fused)
    write_jsonl(out, "rejected_fusion_records.jsonl", rejected)

    summary = {
        "method": "unweighted_conservative_field_union_v3",
        "doi_policy": DOI_POLICY,
        "input_stats": stats,
        "processed_dois": len(keys),
        "fused_candidate_records": len(fused),
        "automatically_completed_records": len(fused),
        "auto_abstained_fields": sum(
            decision == "automatic_null_on_tie"
            for log in logs
            for decision in log["automatic_decisions"].values()
        ),
        "same_model_exact_copies_removed": len(removed),
        "confidence_definition": "macro_average_distinct_model_support_not_accuracy",
        "original_paper_verification": "not_used_or_required",
    }
    with (out / "run_summary.json").open("w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)
        f.write("\n")
    print("[fusion_v3:done]", json.dumps(summary, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()