
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
SteelProBench Stage 3 Post-processing

Processing order:
    0. Classification filtering and remapping
    1. Mechanical unit conversion
    2. Metallurgy-aware noise filtering
    3. DOI-scoped deduplication
    4. Final JSONL / CSV / Log output

Important:
    - Unmappable classifications are filtered BEFORE cleaning/logging.
    - Filtered records do not appear in postprocess_log.csv.
    - Valid classifications are rewritten as "Parent/Child".
    - Final JSONL contains exactly one JSON object per line.
    - Log final status is "keep" or "remove" (no index is output).
    - All original input columns are preserved for eligible records.

Python >= 3.10
"""

from __future__ import annotations

import csv
import itertools
import json
import math
import os
import re
import sqlite3
import time

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional


# ============================================================
# 1. Configuration
# ============================================================

@dataclass(frozen=True)
class Config:

    INPUT_DIR: str = "./fusion"
    OUTPUT_DIR: str = "./process"

    # Metallurgy thresholds
    # Broad data-cleaning bounds, not material-grade acceptance standards.
    # All mechanical limits are inclusive after unit normalization.
    TENSILE_MIN_MPA: float = 200.0
    TENSILE_MAX_MPA: float = 6000.0
    YIELD_MIN_MPA: float = 120.0
    YIELD_MAX_MPA: float = 6000.0
    ELONGATION_MIN_PERCENT: float = 0.0
    ELONGATION_MAX_PERCENT: float = 100.0

    # YS/UTS: reject implausibly small ratios and values far above 1.
    YIELD_TENSILE_RATIO_MIN: float = 0.05
    YIELD_GT_TENSILE_TOLERANCE: float = 0.05

    COMPOSITION_MAX_SUM: float = 105.0

    MAX_PROCESS_CHARS: int = 20000

    # Deduplication protections
    PROTECT_MATERIAL_NAME_CONFLICT: bool = True
    PROTECT_CLASSIFICATION_CONFLICT: bool = True
    PROTECT_CHEMISTRY_CONFLICT: bool = True
    PROTECT_PROCESS_CONFLICT: bool = True

    CHEM_CONFLICT_ABS_WT_PERCENT: float = 0.5
    CHEM_CONFLICT_RELATIVE_FRACTION: float = 0.05

    NUMERIC_PRECISION: int = 6

    SQL_BATCH_SIZE: int = 500

    F_SYNC_OUTPUTS: bool = True

    # Remove obsolete JSON output after successful JSONL export
    REMOVE_LEGACY_JSON: bool = True


CFG = Config()


# ============================================================
# 2. Element and property definitions
# ============================================================

ELEMENTS = (
    "H", "B", "C", "N", "O", "F",
    "Na", "Mg", "Al", "Si", "P", "S",
    "Cl", "Ca", "Ti", "V", "Cr", "Mn",
    "Fe", "Co", "Ni", "Cu", "Zn",
    "As", "Y", "Zr", "Nb", "Mo",
    "Sn", "Sb", "La", "Ce", "Ta",
    "W", "Pb", "Bi"
)

PROPERTIES = (
    "tensile_strength",
    "yield_strength",
    "elongation"
)

UNITS = (
    "tensile_unit",
    "yield_unit",
    "elongation_unit"
)


# ============================================================
# 3. Classification mapping
# ============================================================

# The allowed subclass taxonomy.
#
# Every eligible record is rewritten to:
#     "Parent category/Subcategory"
#
# Examples:
#     IF -> Carbon & Low-alloy Steels/IF
#     DP -> Advanced High-Strength Steels (AHSS)/DP
#
# Unmappable records are immediately excluded.
#
# No cleaning, deduplication or per-record logging is performed
# for excluded records.

CLASSIFICATION_MAPPING = {

    "Carbon & Low-alloy Steels": [
        "Carbon steel",
        "Low-alloy steel",
        "HSLA",
        "IF",
        "Electrical steel"
    ],

    "Advanced High-Strength Steels (AHSS)": [
        "DP",
        "TRIP",
        "CP",
        "TWIP",
        "Q&P",
        "Medium-Mn steel",
        "FB",
        "BH",
        "MART",
        "PHS"
    ],

    "Stainless Steels": [
        "Austenitic stainless steel",
        "Ferritic stainless steel",
        "Martensitic stainless steel",
        "Duplex stainless steel",
        "Precipitation-hardening stainless steel"
    ],

    "Tool & Special Steels": [
        "Tool steel",
        "Maraging steel"
    ],

    "Fe-based alloys without further subdivision": [
        "Fe-based alloy",
        "Unknown"
    ]
}


# ============================================================
# 4. Log columns
# ============================================================

# The original input fields are preserved.
# Exactly seven processing columns are appended.

LOG_EXTRA_FIELDS = (

    "unit_conversion_operations",
    "unit_conversion_status",

    "noise_operations",
    "noise_status",

    "dedup_operations",
    "dedup_status",

    "final_status"
)


# ============================================================
# 5. Basic helper functions
# ============================================================

_NUM = re.compile(
    r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?\Z"
)

_QUANTITY = re.compile(
    r"^\s*([-+]?(?:\d+(?:\.\d*)?|\.\d+)"
    r"(?:[eE][-+]?\d+)?)\s*(.*?)\s*$"
)


def canonical(value: Any) -> str:
    """Normalize whitespace without changing the meaning."""

    if isinstance(value, str):
        return re.sub(r"\s+", " ", value).strip()

    return ""


# ============================================================
# 6. Build classification lookup
# ============================================================

# Matching is case-insensitive and whitespace-normalized.
# Output labels always use the exact taxonomy spelling.

CLASSIFICATION_LOOKUP = {

    canonical(small).casefold(): f"{large}/{small}"

    for large, small_categories in CLASSIFICATION_MAPPING.items()

    for small in small_categories
}


def mapped_classification(record: Any) -> Optional[str]:
    """
    Map the classification field to Parent/Child.

    Examples:
        IF:
            Carbon & Low-alloy Steels/IF

        DP:
            Advanced High-Strength Steels (AHSS)/DP

        Unknown:
            Fe-based alloys without further subdivision/Unknown

    An already-canonical Parent/Child value is also accepted.

    Returns None if:
        - record is not a dictionary
        - classification is absent
        - classification is null or empty
        - classification is not in the allowed taxonomy
        - Parent/Child has a mismatched parent category
    """

    if not isinstance(record, dict):
        return None

    label = canonical(
        record.get("classification")
    )

    if not label:
        return None

    # Direct subclass matching
    match = CLASSIFICATION_LOOKUP.get(
        label.casefold()
    )

    if match is not None:
        return match

    # Accept already-normalized Parent/Child strings
    if "/" in label:

        large, small = label.rsplit("/", 1)

        match = CLASSIFICATION_LOOKUP.get(
            canonical(small).casefold()
        )

        if match is not None:

            expected_parent = match.rsplit("/", 1)[0]

            if (
                canonical(large).casefold()
                == expected_parent.casefold()
            ):
                return match

    return None


def is_unknown_classification(label: Any) -> bool:
    """
    Preserve the original Unknown wildcard behavior
    during classification conflict checks.
    """

    value = canonical(label).casefold()

    return value in {
        "unknown",
        CLASSIFICATION_LOOKUP["unknown"].casefold()
    }


def num(value: Any) -> Optional[float]:
    """Convert valid numeric values to finite floats."""

    if value is None or isinstance(value, bool):
        return None

    try:

        if isinstance(value, (int, float)):
            v = float(value)

        elif (
            isinstance(value, str)
            and _NUM.fullmatch(
                value.strip().replace(",", "")
            )
        ):

            v = float(
                value.strip().replace(",", "")
            )

        else:
            return None

    except (
        TypeError,
        OverflowError,
        ValueError
    ):
        return None

    return v if math.isfinite(v) else None


def unit_key(value: Any) -> str:
    """Normalize unit spelling for conversion."""

    return (
        canonical(value)
        .casefold()
        .replace(" ", "")
        .replace("μ", "µ")
        .replace("µ", "u")
        .replace("²", "^2")
        .replace("℃", "°c")
    )


# ============================================================
# 7. Mechanical unit conversion
# ============================================================

def parse_measurement(
    raw: Any,
    explicit_unit: Any = None

) -> tuple[Optional[float], str, Optional[str]]:
    """
    Parse a mechanical measurement.

    Returns:
        (numeric_value, original_unit, error_code)

    No missing unit is guessed.
    """

    explicit = canonical(explicit_unit)

    plain = num(raw)

    if plain is not None:

        if explicit:
            return plain, explicit, None

        return plain, "", "missing_unit"

    if isinstance(raw, str):

        match = _QUANTITY.fullmatch(raw)

        if match:

            value = float(match.group(1))

            embedded = match.group(2).strip()

            if not math.isfinite(value):

                return (
                    None,
                    embedded,
                    "invalid_number"
                )

            if (
                embedded
                and explicit
                and unit_key(embedded) != unit_key(explicit)
            ):

                return (
                    None,
                    embedded,
                    "inconsistent_embedded_and_explicit_unit"
                )

            resolved = embedded or explicit

            return (
                value,
                resolved,
                None if resolved else "missing_unit"
            )

    return None, explicit, "invalid_quantity"


def canonical_target(kind: str) -> str:

    return (
        "MPa"
        if kind == "strength"
        else "%"
    )


def convert_measurement(
    value: float,
    unit: str,
    kind: str

) -> Optional[tuple[float, str]]:
    """
    Normalize:
        tensile_strength -> MPa
        yield_strength   -> MPa
        elongation       -> %
    """

    u = unit_key(unit)

    if kind == "strength":

        factors = {

            "mpa": 1.0,
            "gpa": 1000.0,
            "kpa": 0.001,
            "pa": 1e-6,

            "n/mm2": 1.0,
            "n/mm^2": 1.0,

            "ksi": 6.894757293168,
            "bar": 0.1
        }

        if u in factors:

            return (
                value * factors[u],
                "MPa"
            )

    elif kind == "elongation":

        factors = {

            "%": 1.0,
            "percent": 1.0,
            "percentage": 1.0,
            "pct": 1.0,

            "fraction": 100.0,
            "ratio": 100.0
        }

        if u in factors:

            return (
                value * factors[u],
                "%"
            )

    else:

        raise ValueError(
            f"Unexpected mechanical category: {kind}"
        )

    return None


def conversion_event(
    field: str,
    raw: Any,
    from_unit: Optional[str],
    kind: str,
    converted: Optional[tuple[float, str]],
    code: Optional[str],
    numeric: Optional[float],
    cfg: Config

) -> dict:
    """Generate a structured unit-conversion event."""

    event = {

        "field": field,

        "from_value": raw,
        "from_unit": from_unit,

        "to_value": None,
        "to_unit": canonical_target(kind),

        "action": (
            "failed"
            if code
            else "unchanged"
        )
    }

    if code:

        event["reason_code"] = code

        return event

    assert converted is not None

    value, target_unit = converted

    value = round(
        value,
        cfg.NUMERIC_PRECISION
    )

    event["to_value"] = value
    event["to_unit"] = target_unit

    if (
        numeric != value
        or from_unit != target_unit
        or isinstance(raw, str)
    ):

        event["action"] = "converted"

    return event


def normalize_units(
    original: Any,
    cfg: Config = CFG

) -> tuple[Any, list[dict], list[dict]]:
    """
    Normalize mechanical property units.

    Only these six columns can change:

        tensile_strength
        tensile_unit
        yield_strength
        yield_unit
        elongation
        elongation_unit

    Other fields remain unchanged.
    """

    if not isinstance(original, dict):

        return original, [], []

    result = dict(original)

    operations: list[dict] = []

    failures: list[dict] = []

    def apply(
        field: str,
        raw: Any,
        explicit: Any,
        kind: str
    ):

        value, from_unit, error = parse_measurement(
            raw,
            explicit
        )

        converted = None

        if error is None:

            converted = convert_measurement(
                value,
                from_unit,
                kind
            )

            if converted is None:

                error = "unsupported_unit"

        ev = conversion_event(
            field,
            raw,
            from_unit or None,
            kind,
            converted,
            error,
            num(raw),
            cfg
        )

        operations.append(ev)

        if error:

            failures.append({

                "field": field,
                "reason_code": error,

                "from_unit": from_unit or None,
                "target_unit": canonical_target(kind),

                "from_value": raw
            })

        return ev

    for prop, unit_field in zip(PROPERTIES, UNITS):

        raw = original.get(prop)

        supplied_unit = original.get(unit_field)

        if raw in (None, ""):

            if supplied_unit not in (None, ""):

                result[unit_field] = None

                operations.append({

                    "field": unit_field,

                    "action": "remove_orphan_unit",

                    "from_value": supplied_unit,
                    "from_unit": supplied_unit,

                    "to_value": None,
                    "to_unit": None
                })

            continue

        kind = (
            "elongation"
            if prop == "elongation"
            else "strength"
        )

        event = apply(
            prop,
            raw,
            supplied_unit,
            kind
        )

        if event["action"] != "failed":

            result[prop] = event["to_value"]

            result[unit_field] = event["to_unit"]

    return result, operations, failures


# ============================================================
# 8. Metallurgy-aware denoising
# ============================================================

def has_process_loop(description: str) -> bool:
    """Detect abnormal repetition in processing descriptions."""

    text = canonical(description).casefold()

    if re.search(r"(.{8,90}?)\1{5,}", text):
        return True

    words = text.split()

    for size in (3, 6, 12):

        for start in range(
            max(
                0,
                len(words) - size * 7 + 1
            )
        ):

            if all(

                words[
                    start + j * size:
                    start + (j + 1) * size
                ]

                == words[start:start + size]

                for j in range(1, 7)

            ):

                return True

    return False


QC_RULES = (

    "record_identity",
    "confidence",

    "mechanical_range",
    "mechanical_relation",
    "mechanical_yield_tensile_ratio",

    "composition_range",
    "composition_total",

    "processing_description",
    "processing_structure"
)


def metallurgy_issues(
    row: Any,
    cfg: Config = CFG

) -> list[dict]:
    """Apply the original metallurgy quality-control rules."""

    if not isinstance(row, dict):

        return [{

            "code": "record_not_object",

            "observed_type": type(row).__name__,

            "raw_value": row
        }]

    issues: list[dict] = []

    def fail(
        code: str,
        field: str,
        **details
    ):

        issues.append({

            "code": code,
            "field": field,

            **details
        })

    # --------------------------------------------------------
    # Record identity
    # --------------------------------------------------------

    if not canonical(row.get("material_name")):

        fail(
            "material_name_missing",
            "material_name"
        )

    if not canonical(row.get("doi")):

        fail(
            "doi_missing",
            "doi"
        )

    # --------------------------------------------------------
    # Confidence
    # --------------------------------------------------------

    confidence = num(
        row.get("confidence_score")
    )

    if (
        confidence is None
        or not 0 <= confidence <= 1
    ):

        fail(

            "invalid_confidence_score",

            "confidence_score",

            observed=row.get("confidence_score"),

            lower=0,
            upper=1
        )

    # --------------------------------------------------------
    # Mechanical properties
    # --------------------------------------------------------

    mechanical: dict[str, Optional[float]] = {}

    strength_bounds = {
        "tensile_strength": (cfg.TENSILE_MIN_MPA, cfg.TENSILE_MAX_MPA),
        "yield_strength": (cfg.YIELD_MIN_MPA, cfg.YIELD_MAX_MPA),
    }

    for prop, unit_field in zip(PROPERTIES, UNITS):
        raw = row.get(prop)

        if raw in (None, ""):
            mechanical[prop] = None
            continue

        value = num(raw)
        mechanical[prop] = value

        if value is None:
            fail("mechanical_not_numeric", prop, observed=raw)
            continue

        if prop == "elongation":
            if not cfg.ELONGATION_MIN_PERCENT <= value <= cfg.ELONGATION_MAX_PERCENT:
                fail(
                    "elongation_out_of_range", prop,
                    observed=value,
                    lower=cfg.ELONGATION_MIN_PERCENT,
                    upper=cfg.ELONGATION_MAX_PERCENT,
                )
            if row.get(unit_field) != "%":
                fail(
                    "elongation_unit_not_percent", unit_field,
                    observed=row.get(unit_field), expected="%",
                )
        else:
            lower, upper = strength_bounds[prop]
            if not lower <= value <= upper:
                fail(
                    "strength_out_of_range", prop,
                    observed=value, lower=lower, upper=upper,
                )
            if row.get(unit_field) != "MPa":
                fail(
                    "strength_unit_not_MPa", unit_field,
                    observed=row.get(unit_field), expected="MPa",
                )

    if all(mechanical[p] is None for p in PROPERTIES):
        fail("all_mechanical_properties_missing", "mechanical")

    uts = mechanical["tensile_strength"]
    ys = mechanical["yield_strength"]

    # Only compare physically meaningful, normalized positive strengths.
    if (
        uts is not None and ys is not None
        and uts > 0 and ys > 0
        and row.get("tensile_unit") == "MPa"
        and row.get("yield_unit") == "MPa"
    ):
        ratio = ys / uts
        if ratio < cfg.YIELD_TENSILE_RATIO_MIN:
            fail(
                "yield_tensile_ratio_too_low", "yield_strength",
                observed_ratio=round(ratio, cfg.NUMERIC_PRECISION),
                minimum_ratio=cfg.YIELD_TENSILE_RATIO_MIN,
                observed_YS=ys, observed_UTS=uts,
            )
        if ratio > 1 + cfg.YIELD_GT_TENSILE_TOLERANCE:
            fail(
                "yield_much_greater_than_tensile", "yield_strength",
                observed_YS=ys, observed_UTS=uts,
                observed_ratio=round(ratio, cfg.NUMERIC_PRECISION),
                maximum_ratio=1 + cfg.YIELD_GT_TENSILE_TOLERANCE,
                relative_tolerance=cfg.YIELD_GT_TENSILE_TOLERANCE,
            )

    # --------------------------------------------------------
    # Chemical composition
    # --------------------------------------------------------

    total = 0.0

    reported = []

    for el in ELEMENTS:

        raw = row.get(el)

        if raw in (None, ""):
            continue

        val = num(raw)

        if (
            val is None
            or not 0 <= val <= 100
        ):

            fail(

                "invalid_composition",

                el,

                observed=raw,

                lower=0,
                upper=100
            )

        else:

            total += val

            reported.append(val)

    if total > cfg.COMPOSITION_MAX_SUM:

        fail(

            "composition_sum_exceeds_limit",

            "composition",

            observed_total=round(
                total,
                cfg.NUMERIC_PRECISION
            ),

            maximum_total=cfg.COMPOSITION_MAX_SUM,

            unit="wt.%"
        )

    if (
        len(reported) >= 2
        and not any(v > 0 for v in reported)
    ):

        fail(

            "all_reported_elements_zero",

            "composition",

            reported_element_count=len(reported)
        )

    # --------------------------------------------------------
    # Processing description
    # --------------------------------------------------------

    desc = row.get("process_description")

    if not canonical(desc):

        fail(

            "process_description_missing",

            "process_description"
        )

    elif len(desc) > cfg.MAX_PROCESS_CHARS:

        fail(

            "process_description_excessive_length",

            "process_description",

            observed_length=len(desc),

            maximum_length=cfg.MAX_PROCESS_CHARS
        )

    elif has_process_loop(desc):

        fail(

            "process_description_repetition_loop",

            "process_description"
        )

    # --------------------------------------------------------
    # Structured processing steps
    # --------------------------------------------------------

    steps = row.get(
        "process_structured_summary"
    )

    if (
        not isinstance(steps, list)
        or not steps
    ):

        fail(

            "process_structured_summary_missing",

            "process_structured_summary"
        )

    elif not all(

        isinstance(step, dict)

        and isinstance(step.get("order"), int)

        and not isinstance(
            step.get("order"),
            bool
        )

        and isinstance(
            step.get("detail"),
            dict
        )

        and bool(
            canonical(step.get("text"))
        )

        for step in steps

    ):

        fail(

            "process_structured_summary_invalid",

            "process_structured_summary"
        )

    return issues


# ============================================================
# 9. DOI normalization and deduplication key
# ============================================================

def normalize_doi(value: Any) -> str:

    doi = canonical(value).casefold()

    doi = re.sub(
        r"^https?://(?:dx\.)?doi\.org/",
        "",
        doi
    )

    return re.sub(
        r"^doi:\s*",
        "",
        doi
    )


def triple_key(row: dict) -> Optional[str]:
    """
    Deduplication key:
        DOI + normalized UTS + normalized YS + normalized EL
    """

    values = [
        num(row.get(prop))
        for prop in PROPERTIES
    ]

    if all(v is None for v in values):

        return None

    return json.dumps(

        [
            normalize_doi(row.get("doi")),
            *values
        ],

        ensure_ascii=False,

        separators=(",", ":")
    )


def key_info(key: Optional[str]) -> dict:

    if not key:
        return {}

    doi, uts, ys, el = json.loads(key)

    return {

        "doi": doi,

        "tensile_strength_MPa": uts,

        "yield_strength_MPa": ys,

        "elongation_percent": el
    }


# ============================================================
# 10. Record quality ranking
# ============================================================

def quality_rank(
    row: dict,
    seq: int

) -> tuple:
    """
    Original ranking priority:

    1. Information completeness
    2. Confidence score
    3. Process step count
    4. Non-null element count
    5. Input order
    """

    cs = num(
        row.get("confidence_score")
    ) or 0.0

    steps = row.get(
        "process_structured_summary"
    )

    step_count = (
        len(steps)
        if isinstance(steps, list)
        else 0
    )

    elements = sum(

        row.get(el) is not None

        for el in ELEMENTS
    )

    properties = sum(

        row.get(p) is not None

        for p in PROPERTIES
    )

    parameters = 0

    if isinstance(steps, list):

        for step in steps:

            if (
                isinstance(step, dict)

                and isinstance(
                    step.get("detail"),
                    dict
                )
            ):

                parameters += sum(

                    val not in (None, "")

                    for field, val
                    in step["detail"].items()

                    if field != "operation"
                )

    return (

        elements
        + properties
        + step_count
        + parameters,

        cs,

        step_count,

        elements,

        -seq
    )


def rank_dict(
    row: dict,
    seq: int

) -> dict:

    completeness, cs, steps, elements, _ = quality_rank(
        row,
        seq
    )

    return {

        "non_null_information_count": completeness,

        "confidence_score": cs,

        "process_step_count": steps,

        "non_null_element_count": elements,

        "input_seq": seq
    }


def selection_reason(
    winner: tuple,
    loser: tuple

) -> dict:

    wi, _, wr = winner

    li, _, lr = loser

    a = quality_rank(wr, wi)

    b = quality_rank(lr, li)

    labels = (

        "non_null_information_count",

        "confidence_score",

        "process_step_count",

        "non_null_element_count",

        "input_seq"
    )

    for index, label in enumerate(labels):

        if a[index] != b[index]:

            return {

                "criterion": label,

                "winner_value": (
                    -wi if index == 4
                    else a[index]
                ),

                "other_value": (
                    -li if index == 4
                    else b[index]
                ),

                "ranking_priority": list(labels)
            }

    return {

        "criterion": "equal",

        "ranking_priority": list(labels)
    }


# ============================================================
# 11. Material-state conflict protection
# ============================================================

def distinct_state_reasons(
    a: dict,
    b: dict,
    cfg: Config = CFG

) -> list[dict]:
    """
    Prevent false deduplication of different material states.
    """

    reasons: list[dict] = []

    # --------------------------------------------------------
    # Material name conflict
    # --------------------------------------------------------

    name_a = canonical(
        a.get("material_name")
    )

    name_b = canonical(
        b.get("material_name")
    )

    if (
        cfg.PROTECT_MATERIAL_NAME_CONFLICT
        and name_a
        and name_b
    ):

        def simple(v):
            return re.sub(
                r"[^a-z0-9]+",
                "",
                v.casefold()
            )

        if simple(name_a) != simple(name_b):

            reasons.append({

                "code": "material_name_conflict",

                "a": name_a,
                "b": name_b
            })

    # --------------------------------------------------------
    # Classification conflict
    # --------------------------------------------------------

    ca = canonical(
        a.get("classification")
    )

    cb = canonical(
        b.get("classification")
    )

    if (

        cfg.PROTECT_CLASSIFICATION_CONFLICT

        and ca
        and cb

        and not is_unknown_classification(ca)
        and not is_unknown_classification(cb)

        and ca != cb
    ):

        reasons.append({

            "code": "classification_conflict",

            "a": ca,
            "b": cb
        })

    # --------------------------------------------------------
    # Chemical composition conflict
    # --------------------------------------------------------

    if cfg.PROTECT_CHEMISTRY_CONFLICT:

        for element in ELEMENTS:

            x = num(a.get(element))

            y = num(b.get(element))

            if x is None or y is None:
                continue

            tolerance = max(

                cfg.CHEM_CONFLICT_ABS_WT_PERCENT,

                cfg.CHEM_CONFLICT_RELATIVE_FRACTION
                * max(abs(x), abs(y))
            )

            if abs(x - y) > tolerance:

                reasons.append({

                    "code": "chemistry_conflict",

                    "field": element,

                    "a": x,
                    "b": y,

                    "allowed_abs_difference": tolerance
                })

                if len(reasons) >= 5:
                    break

    # --------------------------------------------------------
    # Processing conflict
    # --------------------------------------------------------

    if cfg.PROTECT_PROCESS_CONFLICT:

        sa = a.get(
            "process_structured_summary"
        )

        sb = b.get(
            "process_structured_summary"
        )

        if (
            isinstance(sa, list)
            and isinstance(sb, list)

            and sa
            and sb
        ):

            aa = [

                x["detail"]

                for x in sorted(
                    sa,
                    key=lambda v: v.get("order", 0)
                )

                if (
                    isinstance(x, dict)
                    and isinstance(
                        x.get("detail"),
                        dict
                    )
                )
            ]

            bb = [

                x["detail"]

                for x in sorted(
                    sb,
                    key=lambda v: v.get("order", 0)
                )

                if (
                    isinstance(x, dict)
                    and isinstance(
                        x.get("detail"),
                        dict
                    )
                )
            ]

            oa = [

                canonical(
                    x.get("operation")
                ).casefold()

                for x in aa
            ]

            ob = [

                canonical(
                    x.get("operation")
                ).casefold()

                for x in bb
            ]

            if oa != ob:

                reasons.append({

                    "code": "processing_sequence_conflict",

                    "a": oa,
                    "b": ob
                })

            else:

                for idx, (da, db) in enumerate(
                    zip(aa, bb),
                    1
                ):

                    for field in da.keys() & db.keys():

                        if field == "operation":
                            continue

                        va = da[field]
                        vb = db[field]

                        if (
                            va in (None, "")
                            or vb in (None, "")
                        ):
                            continue

                        if (

                            canonical(
                                str(va)
                            ).casefold()

                            !=

                            canonical(
                                str(vb)
                            ).casefold()
                        ):

                            reasons.append({

                                "code": "processing_parameter_conflict",

                                "step": idx,

                                "field": field,

                                "a": va,
                                "b": vb
                            })

                            if len(reasons) >= 5:
                                break

                    if len(reasons) >= 5:
                        break

    return reasons


# ============================================================
# 12. Discover fused JSONL input files
# ============================================================

def fused_files(root: Path) -> list[Path]:

    shards = sorted(

        p for p in root.glob("fused_*.jsonl")

        if re.fullmatch(
            r"fused_\d{6}\.jsonl",
            p.name
        )
    )

    if shards:
        return shards

    single = root / "fused.jsonl"

    return (
        [single]
        if single.is_file()
        else []
    )


# ============================================================
# 13. Initialize SQLite staging database
# ============================================================

def initialize_db(conn: sqlite3.Connection) -> None:

    conn.executescript("""
    CREATE TABLE items (

        seq INTEGER PRIMARY KEY,

        locator TEXT NOT NULL,

        raw_json TEXT NOT NULL,

        normalized_json TEXT NOT NULL,

        key TEXT,

        unit_json TEXT NOT NULL,

        unit_status TEXT NOT NULL,

        noise_json TEXT NOT NULL,

        noise_status TEXT NOT NULL,

        dedup_json TEXT NOT NULL DEFAULT '{}',

        dedup_status TEXT NOT NULL,

        duplicate_of INTEGER,

        final_index INTEGER
    );

    CREATE INDEX ix_items_key
        ON items(key);

    CREATE INDEX ix_items_noise_status
        ON items(noise_status);
    """)


# ============================================================
# 14. Import records
#     Classification filtering happens FIRST
# ============================================================

def import_fused(
    conn: sqlite3.Connection,
    files: list[Path],
    cfg: Config

) -> tuple[dict, list[str]]:
    """
    Import JSONL data into SQLite.

    IMPORTANT ORDER:

    1. Read a JSONL record.
    2. Validate and remap classification.
    3. If classification cannot be mapped:
           discard immediately.
    4. Only accepted records enter unit conversion.
    5. Only accepted records enter noise filtering.
    6. Only accepted records are stored for logging.

    Invalid classification rows:
        - are not cleaned
        - are not deduplicated
        - have no per-record log
        - do not enter final JSONL
        - do not enter final CSV

    Only a total excluded-row count is kept in summary.json.
    """

    sql = """
    INSERT INTO items (

        seq,
        locator,

        raw_json,
        normalized_json,

        key,

        unit_json,
        unit_status,

        noise_json,
        noise_status,

        dedup_json,
        dedup_status

    )

    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """

    columns: list[str] = []

    seen: set[str] = set()

    stats = {

        # Total original JSONL records
        "input_records": 0,

        # Classification filtering
        "filtered_unmapped_classification": 0,

        # Records allowed into cleaning
        "eligible_records": 0,

        # Existing cleaning statistics
        "removed_noise": 0,

        "records_with_unit_conversion": 0,

        "unit_conversion_operations": 0,

        "records_with_unit_failure": 0
    }

    batch = []

    for path in files:

        with path.open(
            "r",
            encoding="utf-8-sig"
        ) as f:

            for line_no, line in enumerate(f, 1):

                if not line.strip():

                    raise ValueError(
                        f"Empty JSONL line: {path}:{line_no}"
                    )

                # ------------------------------------------------
                # Read input JSONL record
                # ------------------------------------------------

                try:

                    raw = json.loads(

                        line,

                        parse_constant=lambda x: (
                            _ for _ in ()
                        ).throw(
                            ValueError(
                                "Invalid JSON number " + x
                            )
                        )
                    )

                except (
                    json.JSONDecodeError,
                    ValueError
                ) as exc:

                    raise ValueError(

                        f"JSONL parse failed at "
                        f"{path}:{line_no}: {exc}"

                    ) from exc

                stats["input_records"] += 1

                # ================================================
                # STEP 0: CLASSIFICATION FILTERING
                # ================================================

                classification = mapped_classification(raw)

                # No valid mapping -> discard immediately
                if classification is None:

                    stats[
                        "filtered_unmapped_classification"
                    ] += 1

                    continue

                # Only eligible records proceed
                stats["eligible_records"] += 1

                # Copy raw record and overwrite classification
                mapped_raw = dict(raw)

                mapped_raw[
                    "classification"
                ] = classification

                # Only collect CSV fields from eligible records
                for k in mapped_raw:

                    if k not in seen:

                        columns.append(k)

                        seen.add(k)

                # ================================================
                # STEP 1: MECHANICAL UNIT CONVERSION
                # ================================================

                normalized, events, unit_failures = (
                    normalize_units(
                        mapped_raw,
                        cfg
                    )
                )

                converted_count = sum(

                    ev["action"] == "converted"

                    for ev in events
                )

                stats[
                    "unit_conversion_operations"
                ] += converted_count

                if converted_count:

                    stats[
                        "records_with_unit_conversion"
                    ] += 1

                if unit_failures:

                    stats[
                        "records_with_unit_failure"
                    ] += 1

                # ================================================
                # STEP 2: METALLURGY-AWARE NOISE FILTER
                # ================================================

                issues = metallurgy_issues(
                    normalized,
                    cfg
                )

                if unit_failures:

                    issues = [

                        {

                            "code": "unit_conversion_failed",

                            "field": issue["field"],

                            "unit_error_code": (
                                issue["reason_code"]
                            ),

                            "from_unit": (
                                issue["from_unit"]
                            ),

                            "target_unit": (
                                issue["target_unit"]
                            ),

                            "from_value": (
                                issue["from_value"]
                            )
                        }

                        for issue in unit_failures

                    ] + issues

                if issues:

                    stats["removed_noise"] += 1

                # ------------------------------------------------
                # Unit conversion status
                # ------------------------------------------------

                if unit_failures:

                    unit_status = "failed"

                elif converted_count:

                    unit_status = "converted"

                else:

                    unit_status = "unchanged"

                # ------------------------------------------------
                # Noise status
                # ------------------------------------------------

                noise_status = (

                    "removed_noise"

                    if issues

                    else "passed"
                )

                noise_ops = {

                    "checks": (
                        list(QC_RULES)
                        + ["unit_conversion_validity"]
                    ),

                    "failed_checks": issues,

                    "failed_check_count": len(issues)
                }

                # ================================================
                # STEP 3: ADD ELIGIBLE RECORD TO SQLITE
                # ================================================

                batch.append((

                    stats["input_records"],

                    f"{path.name}:{line_no}",

                    # Classification is already rewritten here
                    json.dumps(
                        mapped_raw,
                        ensure_ascii=False,
                        allow_nan=False
                    ),

                    json.dumps(
                        normalized,
                        ensure_ascii=False,
                        allow_nan=False
                    ),

                    (
                        triple_key(normalized)

                        if (
                            isinstance(normalized, dict)
                            and not issues
                        )

                        else None
                    ),

                    json.dumps(
                        events,
                        ensure_ascii=False,
                        allow_nan=False
                    ),

                    unit_status,

                    json.dumps(
                        noise_ops,
                        ensure_ascii=False,
                        allow_nan=False
                    ),

                    noise_status,

                    json.dumps(

                        (
                            {
                                "action": "skip",
                                "reason_code": "noise_removed"
                            }

                            if issues

                            else {
                                "action": "pending"
                            }
                        ),

                        ensure_ascii=False
                    ),

                    (
                        "skipped_noise"

                        if issues

                        else "pending"
                    )
                ))

                # ------------------------------------------------
                # Batch database insertion
                # ------------------------------------------------

                if len(batch) >= cfg.SQL_BATCH_SIZE:

                    conn.executemany(
                        sql,
                        batch
                    )

                    batch.clear()

    if batch:

        conn.executemany(
            sql,
            batch
        )

    conn.commit()

    return stats, columns


# ============================================================
# 15. DOI-scoped deduplication
# ============================================================

def resolve_duplicates(
    conn: sqlite3.Connection,
    cfg: Config

) -> tuple[int, int]:
    """
    Deduplication scope:

        Same DOI
        Same normalized UTS / YS / EL

    Additional conflict protection:
        - material name
        - classification
        - chemistry
        - processing sequence and parameters
    """

    rows = conn.execute(

        """
        SELECT
            seq,
            locator,
            normalized_json,
            key

        FROM items

        WHERE noise_status = 'passed'

        ORDER BY key, seq
        """
    )

    sql = """

    UPDATE items

    SET
        dedup_json = ?,
        dedup_status = ?,
        duplicate_of = ?

    WHERE seq = ?
    """

    updates = []

    removed = 0

    protected_pairs: set[tuple[int, int]] = set()

    for key, group_iter in itertools.groupby(

        rows,

        key=lambda x: x[3]
    ):

        candidates = [

            (
                seq,
                locator,
                json.loads(raw)
            )

            for seq, locator, raw, _ in group_iter
        ]

        clusters: list[
            list[tuple[int, str, dict]]
        ] = []

        protected: dict[int, list[dict]] = {}

        for candidate in candidates:

            seq, loc, record = candidate

            assigned = False

            for cluster in clusters:

                comparisons = [

                    (
                        other,

                        distinct_state_reasons(
                            record,
                            other[2],
                            cfg
                        )
                    )

                    for other in cluster
                ]

                if all(

                    not reasons

                    for _, reasons in comparisons
                ):

                    cluster.append(candidate)

                    assigned = True

                    break

                for other, reasons in comparisons:

                    if not reasons:
                        continue

                    other_seq, other_loc, other_record = other

                    protected_pairs.add(

                        tuple(
                            sorted(
                                (seq, other_seq)
                            )
                        )
                    )

                    protected.setdefault(
                        seq,
                        []
                    ).append({

                        "input_location": other_loc,

                        "exclusion_reasons": reasons
                    })

                    protected.setdefault(
                        other_seq,
                        []
                    ).append({

                        "input_location": loc,

                        "exclusion_reasons": (
                            distinct_state_reasons(
                                other_record,
                                record,
                                cfg
                            )
                        )
                    })

            if not assigned:

                clusters.append(
                    [candidate]
                )

        # ----------------------------------------------------
        # Choose representative in each compatible cluster
        # ----------------------------------------------------

        for cluster in clusters:

            winner = max(

                cluster,

                key=lambda x: quality_rank(
                    x[2],
                    x[0]
                )
            )

            win_seq, win_loc, win_record = winner

            cluster_members = [

                loc

                for _, loc, _ in cluster
            ]

            for seq, loc, record in cluster:

                other_locs = [

                    x

                    for x in cluster_members

                    if x != loc
                ]

                protected_candidates = protected.get(
                    seq,
                    []
                )

                by_locator = {

                    item["input_location"]: item

                    for item in protected_candidates
                }

                common = {

                    "dedup_key": key_info(key),

                    "matching_candidates": other_locs,

                    "protected_nonduplicates": list(
                        by_locator.values()
                    ),

                    "selection_priority": [

                        "non_null_information_count",

                        "confidence_score",

                        "process_step_count",

                        "non_null_element_count",

                        "input_order"
                    ]
                }

                if seq == win_seq:

                    status = "kept"

                    duplicate_of = None

                    details = {

                        **common,

                        "action": (

                            "keep_representative"

                            if other_locs

                            else "keep_distinct"
                        ),

                        "representative_location": win_loc,

                        "record_quality": rank_dict(
                            record,
                            seq
                        ),

                        "duplicate_count": len(other_locs),

                        "selection": (

                            {
                                "criterion": "best_rank_in_cluster"
                            }

                            if other_locs

                            else {
                                "criterion": "no_compatible_duplicate"
                            }
                        )
                    }

                else:

                    status = "removed_duplicate"

                    duplicate_of = win_seq

                    removed += 1

                    details = {

                        **common,

                        "action": "remove_duplicate",

                        "reason_codes": [

                            "same_doi",

                            "same_normalized_mechanical_triple",

                            "compatible_material_chemistry_processing"
                        ],

                        "representative_location": win_loc,

                        "selection": selection_reason(

                            winner,

                            (
                                seq,
                                loc,
                                record
                            )
                        ),

                        "record_quality": rank_dict(
                            record,
                            seq
                        ),

                        "representative_quality": rank_dict(
                            win_record,
                            win_seq
                        )
                    }

                updates.append((

                    json.dumps(
                        details,
                        ensure_ascii=False,
                        allow_nan=False
                    ),

                    status,

                    duplicate_of,

                    seq
                ))

                if len(updates) >= cfg.SQL_BATCH_SIZE:

                    conn.executemany(
                        sql,
                        updates
                    )

                    updates.clear()

    if updates:

        conn.executemany(
            sql,
            updates
        )

    conn.commit()

    return removed, len(protected_pairs)


# ============================================================
# 16. Assign final record indices
# ============================================================

def assign_final_indices(
    conn: sqlite3.Connection

) -> int:
    """
    Assign zero-based indices to final retained records.

    These indices correspond to:
        final_clean.jsonl
        final_clean.csv
    """

    count = 0

    for (seq,) in conn.execute(

        """
        SELECT seq

        FROM items

        WHERE dedup_status = 'kept'

        ORDER BY seq
        """
    ):

        conn.execute(

            """
            UPDATE items

            SET final_index = ?

            WHERE seq = ?
            """,

            (
                count,
                seq
            )
        )

        count += 1

    conn.commit()

    return count


# ============================================================
# 17. CSV serialization
# ============================================================

def export_nulls(value: Any) -> Any:
    """Replace empty field/attribute values with JSON null at export time."""

    if value is None:
        return None

    if isinstance(value, str) and not value.strip():
        return None

    if isinstance(value, dict):
        return {
            key: export_nulls(item)
            for key, item in value.items()
        }

    if isinstance(value, (list, tuple)):
        return [export_nulls(item) for item in value]

    return value


def csv_cell(value: Any) -> Any:
    """Convert nested JSON structures to CSV cell strings."""

    value = export_nulls(value)

    if value is None:
        return "null"

    if isinstance(
        value,
        (dict, list, tuple)
    ):

        return json.dumps(
            value,
            ensure_ascii=False,
            allow_nan=False
        )

    if isinstance(value, bool):

        return (
            "True"
            if value
            else "False"
        )

    return value


def write_csv(
    path: Path,
    columns: list[str],
    records,
    fsync: bool

) -> int:
    """Write CSV atomically."""

    temp = path.with_name(
        path.name + ".tmp"
    )

    count = 0

    with temp.open(
        "w",
        encoding="utf-8-sig",
        newline=""
    ) as f:

        writer = csv.DictWriter(

            f,

            fieldnames=columns,

            extrasaction="ignore",

            lineterminator="\n"
        )

        writer.writeheader()

        for record in records:

            writer.writerow({

                field: csv_cell(
                    record.get(field)
                )

                for field in columns
            })

            count += 1

        f.flush()

        if fsync:

            os.fsync(
                f.fileno()
            )

    os.replace(
        temp,
        path
    )

    return count


# ============================================================
# 18. JSONL serialization
# ============================================================

def write_jsonl(
    path: Path,
    records,
    fsync: bool

) -> int:
    """
    Write JSONL instead of a JSON array.

    Correct output format:

        {"doi":"...","classification":"..."}
        {"doi":"...","classification":"..."}
        {"doi":"...","classification":"..."}

    Each line is one independent JSON object.
    """

    temp = path.with_name(
        path.name + ".tmp"
    )

    count = 0

    with temp.open(
        "w",
        encoding="utf-8",
        newline="\n"
    ) as f:

        for record in records:

            f.write(

                json.dumps(

                    export_nulls(record),

                    ensure_ascii=False,

                    allow_nan=False,

                    separators=(",", ":")
                )

                + "\n"
            )

            count += 1

        f.flush()

        if fsync:

            os.fsync(
                f.fileno()
            )

    os.replace(
        temp,
        path
    )

    return count


# ============================================================
# 19. Final clean record iterator
# ============================================================

def clean_records(
    conn: sqlite3.Connection
):
    """
    Yield final retained records in final_index order.

    Classification was rewritten before cleaning and is
    preserved in each output record.
    """

    for (raw,) in conn.execute(

        """
        SELECT normalized_json

        FROM items

        WHERE dedup_status = 'kept'

        ORDER BY final_index
        """
    ):

        yield json.loads(raw)


# ============================================================
# 20. Processing log iterator
# ============================================================

def log_records(
    conn: sqlite3.Connection
):
    """
    Create logs only for classification-eligible inputs.

    Unmappable classification records were never inserted
    into the SQLite items table, so they never appear here.

    Exactly seven processing columns are appended.
    """

    rows = conn.execute(

        """
        SELECT

            locator,

            raw_json,

            unit_json,
            unit_status,

            noise_json,
            noise_status,

            dedup_json,
            dedup_status,

            final_index

        FROM items

        ORDER BY seq
        """
    )

    for (

        locator,
        raw,

        unit_json,
        unit_status,

        noise_json,
        noise_status,

        dedup_json,
        dedup_status,

        final_index

    ) in rows:

        original = json.loads(raw)

        fields = (

            dict(original)

            if isinstance(original, dict)

            else {}
        )

        # The input source location is stored inside
        # dedup_operations instead of creating another
        # CSV column.

        dedup_detail = json.loads(
            dedup_json
        )

        dedup_detail[
            "source_location"
        ] = locator

        kept = (

            noise_status == "passed"

            and dedup_status == "kept"
        )

        fields.update({

            "unit_conversion_operations": json.loads(unit_json),

            "unit_conversion_status": unit_status,

            "noise_operations": json.loads(noise_json),

            "noise_status": noise_status,

            "dedup_operations": dedup_detail,

            "dedup_status": dedup_status,

            "final_status": (

                "keep"

                if kept

                else "remove"
            )
        })

        yield fields


# ============================================================
# 21. Main processing function
# ============================================================

def run(
    cfg: Config = CFG

) -> dict:

    # --------------------------------------------------------
    # Validate configuration
    # --------------------------------------------------------

    if (

        cfg.SQL_BATCH_SIZE < 1

        or not (
            0 <= cfg.NUMERIC_PRECISION <= 15
        )
    ):

        raise ValueError(

            "Invalid SQL_BATCH_SIZE or NUMERIC_PRECISION"
        )

    # Validate mechanical bounds before any file is opened.
    limits = (
        cfg.TENSILE_MIN_MPA, cfg.TENSILE_MAX_MPA,
        cfg.YIELD_MIN_MPA, cfg.YIELD_MAX_MPA,
        cfg.ELONGATION_MIN_PERCENT, cfg.ELONGATION_MAX_PERCENT,
        cfg.YIELD_TENSILE_RATIO_MIN, cfg.YIELD_GT_TENSILE_TOLERANCE,
    )
    if not all(math.isfinite(v) for v in limits):
        raise ValueError("Mechanical thresholds must be finite")
    if not (
        0 < cfg.TENSILE_MIN_MPA <= cfg.TENSILE_MAX_MPA
        and 0 < cfg.YIELD_MIN_MPA <= cfg.YIELD_MAX_MPA
        and 0 <= cfg.ELONGATION_MIN_PERCENT <= cfg.ELONGATION_MAX_PERCENT <= 100
        and 0 <= cfg.YIELD_TENSILE_RATIO_MIN <= 1
        and 0 <= cfg.YIELD_GT_TENSILE_TOLERANCE <= 1
    ):
        raise ValueError("Invalid mechanical threshold configuration")

    # --------------------------------------------------------
    # Find input files
    # --------------------------------------------------------

    input_dir = Path(
        cfg.INPUT_DIR
    )

    files = fused_files(
        input_dir
    )

    if not files:

        raise FileNotFoundError(

            "No fused_000001.jsonl or fused.jsonl "
            f"found in {input_dir}"
        )

    # --------------------------------------------------------
    # Prepare output directory
    # --------------------------------------------------------

    out = Path(
        cfg.OUTPUT_DIR
    )

    if (
        out.resolve()
        == input_dir.resolve()
    ):

        raise ValueError(

            "INPUT_DIR and OUTPUT_DIR must differ"
        )

    out.mkdir(
        parents=True,
        exist_ok=True
    )

    # --------------------------------------------------------
    # Incomplete-run marker
    # --------------------------------------------------------

    marker = out / "_postprocess_incomplete.json"

    marker.write_text(

        json.dumps({

            "started_at": time.strftime(
                "%Y-%m-%dT%H:%M:%S"
            ),

            "sources": [
                str(p)
                for p in files
            ]

        },

        ensure_ascii=False,
        indent=2
        ),

        encoding="utf-8"
    )

    # --------------------------------------------------------
    # SQLite staging
    # --------------------------------------------------------

    staging = out / "_postprocess_staging.sqlite3"

    staging.unlink(
        missing_ok=True
    )

    started = time.perf_counter()

    conn = sqlite3.connect(
        staging
    )

    try:

        initialize_db(conn)

        # ====================================================
        # STEP 0-2:
        # Classification filtering + unit + noise
        # ====================================================

        stats, input_fields = import_fused(
            conn,
            files,
            cfg
        )

        # ====================================================
        # STEP 3:
        # Deduplication
        # ====================================================

        duplicates, protected = resolve_duplicates(
            conn,
            cfg
        )

        # ====================================================
        # STEP 4:
        # Assign final output indices
        # ====================================================

        kept = assign_final_indices(
            conn
        )

        # ----------------------------------------------------
        # Build final CSV column list
        # ----------------------------------------------------

        final_fields = list(
            input_fields
        )

        seen = set(
            final_fields
        )

        for (normalized,) in conn.execute(

            """
            SELECT normalized_json

            FROM items
            """
        ):

            record = json.loads(
                normalized
            )

            if isinstance(record, dict):

                for field in record:

                    if field not in seen:

                        final_fields.append(
                            field
                        )

                        seen.add(
                            field
                        )

        # ----------------------------------------------------
        # Prevent collisions with reserved log columns
        # ----------------------------------------------------

        collisions = (

            set(input_fields)

            & set(LOG_EXTRA_FIELDS)
        )

        if collisions:

            raise ValueError(

                "Input columns conflict with "
                "reserved log columns: "

                + ", ".join(
                    sorted(collisions)
                )
            )

        log_fields = (

            input_fields

            + list(LOG_EXTRA_FIELDS)
        )

        # ====================================================
        # STEP 5:
        # Write final JSONL
        # ====================================================

        jsonl_count = write_jsonl(

            out / "final_clean.jsonl",

            clean_records(conn),

            cfg.F_SYNC_OUTPUTS
        )

        # ====================================================
        # STEP 6:
        # Write final CSV
        # ====================================================

        csv_count = write_csv(

            out / "final_clean.csv",

            final_fields,

            clean_records(conn),

            cfg.F_SYNC_OUTPUTS
        )

        # ====================================================
        # STEP 7:
        # Write processing log
        # ====================================================

        log_count = write_csv(

            out / "postprocess_log.csv",

            log_fields,

            log_records(conn),

            cfg.F_SYNC_OUTPUTS
        )

        # ====================================================
        # STEP 8:
        # Validate record counts
        # ====================================================

        if not (

            jsonl_count
            == csv_count
            == kept
        ):

            raise AssertionError(

                "JSONL/CSV/final kept counts differ"
            )

        # Only eligible records participate in logging
        if log_count != stats["eligible_records"]:

            raise AssertionError(

                "Log rows must equal "
                "classification-eligible records"
            )

        # Classification filter count
        if (

            stats["filtered_unmapped_classification"]

            + stats["eligible_records"]

            != stats["input_records"]
        ):

            raise AssertionError(

                "Classification filtering counts "
                "do not balance"
            )

        # Post-processing count
        if (

            kept

            + duplicates

            + stats["removed_noise"]

            != stats["eligible_records"]
        ):

            raise AssertionError(

                "Eligible/kept/noise/duplicate "
                "counts do not balance"
            )

        # ====================================================
        # STEP 9:
        # Generate summary
        # ====================================================

        summary = {

            **stats,

            "kept_records": kept,

            "removed_duplicate": duplicates,

            "protected_potential_false_duplicates": protected,

            "jsonl_records": jsonl_count,

            "csv_records": csv_count,

            "log_records": log_count,

            "processing_order": [

                "classification_filter_and_remap",

                "unit_conversion",

                "noise_filter",

                "deduplication"
            ],

            "strict_filter_on_unconvertible_mechanical_unit": True,

            "process_parameters_unit_converted": False,

            "log_extra_columns": list(
                LOG_EXTRA_FIELDS
            ),

            "final_status_index_base": 0,

            "unit_targets": {

                "tensile_strength": "MPa",

                "yield_strength": "MPa",

                "elongation": "%"
            },

            "dedup_scope": (
                "same_doi_and_exact_normalized_UTS_YS_EL"
            ),

            "input_shards": [
                p.name
                for p in files
            ],

            "outputs": [

                "final_clean.jsonl",

                "final_clean.csv",

                "postprocess_log.csv"
            ],

            "elapsed_seconds": round(

                time.perf_counter() - started,

                3
            )
        }

        # ----------------------------------------------------
        # Save summary atomically
        # ----------------------------------------------------

        temp = out / "summary.json.tmp"

        temp.write_text(

            json.dumps(

                summary,

                ensure_ascii=False,

                indent=2
            ),

            encoding="utf-8"
        )

        os.replace(

            temp,

            out / "summary.json"
        )

        # ----------------------------------------------------
        # Remove obsolete final_clean.json
        # ----------------------------------------------------

        if cfg.REMOVE_LEGACY_JSON:

            (
                out / "final_clean.json"
            ).unlink(
                missing_ok=True
            )

        # ----------------------------------------------------
        # Successful completion
        # ----------------------------------------------------

        marker.unlink(
            missing_ok=True
        )

        print(

            "[postprocess:complete]",

            json.dumps(
                summary,
                ensure_ascii=False
            ),

            flush=True
        )

        return summary

    finally:

        conn.close()

        staging.unlink(
            missing_ok=True
        )


# ============================================================
# 22. Program entry
# ============================================================

if __name__ == "__main__":

    run()