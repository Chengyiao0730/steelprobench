#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Single-model material extraction, resumable directly from per-model JSONL shards."""
from __future__ import annotations

import json
import math
import os
import re
import time
import traceback
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional
from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED
from threading import local

# Edit this value instead of using CLI arguments.
SELECTED_MODEL = "gptoss_20b"  # "gemma3_27b" or "gptoss_20b"

INPUT_DIR = "/home/talia/chengyiao/json"
OUTPUT_DIR = "/home/talia/chengyiao/gptoss/gptoss"
INPUT_RECURSIVE = True
MAX_PAPERS = None
MAX_RECORDS_PER_JSONL = 2000

ELEMENTS = ('H', 'B', 'C', 'N', 'O', 'F', 'Na', 'Mg', 'Al', 'Si', 'P', 'S', 'Cl', 'Ca', 'Ti', 'V', 'Cr', 'Mn', 'Fe', 'Co', 'Ni', 'Cu', 'Zn', 'As', 'Y', 'Zr', 'Nb', 'Mo', 'Sn', 'Sb', 'La', 'Ce', 'Ta', 'W', 'Pb', 'Bi')

PROPERTIES = ('tensile_strength', 'yield_strength', 'elongation')

UNITS = ('tensile_unit', 'yield_unit', 'elongation_unit')

CLASSIFICATIONS = ('IF', 'BH', 'HSLA', 'DP', 'TRIP', 'TWIP', 'MART', 'CP', 'FB', 'PHS', 'Q&P', 'Medium-Mn steel', 'Austenitic stainless steel', 'Ferritic stainless steel', 'Martensitic stainless steel', 'Duplex stainless steel', 'Precipitation-hardening stainless steel', 'Tool steel', 'Maraging steel', 'Electrical steel', 'Carbon steel', 'Low-alloy steel', 'Fe-based alloy', 'Ti alloy', 'Ni-based alloy', 'Al alloy', 'Cu alloy', 'Mg alloy', 'Co-based alloy', 'High-entropy alloy', 'Other metallic alloy', 'Unknown')

SYSTEM_PROMPT = 'You are a precise scientific extraction engine specialized in\nexperimental metallic materials. Output ONE JSON object with a "records" array.\nEvery array item MUST be a COMPLETE, FLAT material data record.\nWrite all new text in ENGLISH. No Markdown, no commentary.\nRead ONLY the supplied PRE_DATA and the COMPLETE TABLES.\nDo not invent, hallucinate, cross-associate different specimens, or use\nknowledge from other papers. Do not treat salts, buffers, etchants, coatings,\nprecipitates, ceramics or solution concentrations as bulk alloy compositions.\nIf the same alloy has different measured treatment states or test conditions,\nreturn separate records. Missing values MUST be null, NEVER invented zeros.'

USER_INSTRUCTIONS = 'EXTRACTION TASK\nReturn exactly {"records": [record, ...]} where each record contains ALL keys in\nthe required template below. Return zero, one, or many records.\n\n1. Record identification:\n - One material/sample AND treatment/test condition per record.\n - material_name is the actual alloy/sample designation in the paper;\n   include a concise condition in the NAME only if needed to distinguish\n   genuinely different treated specimens. Never include "Table N: Row M".\n - doi is supplied explicitly below. Do not make up measurements.\n\n2. Mechanical properties:\n - tensile_strength and yield_strength must be numeric MPa;\n   elongation must be numeric percent (%). Put matching units in the\n   tensile_unit, yield_unit, and elongation_unit fields.\n - Convert supported reported units (e.g. GPa -> MPa) correctly.\n - Never confuse hardness, elastic modulus or shear strength with tensile\n   strength/yield strength; never confuse testing strain with elongation.\n - During THIS extraction, do not require any of the three properties to\n   exist. Return candidates even with all three null when there is\n   otherwise meaningful relevant material evidence. Python will filter\n   them later.\n\n3. CHEMISTRY: each listed element field is wt.% (MASS PERCENT):\n - Extract accurate elemental *bulk alloy composition* for this exact\n   material. DO NOT map a composition of a different alloy to it.\n - Convert at.% to wt.% with atomic masses ONLY if enough measured elemental\n   amounts are available for a reliable complete conversion.\n - Never confuse element 0 wt.% with "not reported": use numeric 0 only\n   if actually stated, otherwise null.\n - If the main matrix element (e.g. Fe for steel, Ti for titanium alloys,\n   Ni for Ni-based alloys, Al for aluminium alloys, Cu for copper alloys)\n   is explicitly \'balance\'/\'remainder\', compute its wt.% as\n   100 - sum(reliably measured OTHER wt.% constituents).\n - You MAY infer the matrix balance from a confidently identified alloy\n   family only when sufficient measured POSITIVE minor-element\n   percentages are present, the chemical system is complete, the sum\n   is physically reasonable, and no unknown significant constituents\n   are omitted. A sum slightly different from 100 within normal\n   measurement/rounding tolerance is acceptable: do not force exact 100.\n - NEVER infer an element (e.g. Fe=100) if every initially observed element\n   is 0 or absent. Never fill from a lone chemical formula or an alloy name\n   without source support.\n - If a requested field is unreported, keep it null. No made-up numbers.\n\n4. PROCESSING, IN THIS SAME MODEL RESPONSE:\n - process_description: prefer ORIGINAL wording from the paper in PRE_DATA\n   and TABLES, ordered chronologically; include relevant preparation,\n   casting, rolling, forging, powder fabrication, heat treatment, aging,\n   sintering, cooling/quenching with measured parameters.\n - Shared processing may be associated with samples only if context supports it.\n - Do not include tensile testing, polishing for microscopy, or\n   unrelated characterization procedures as manufacturing steps.\n - process_structured_summary: an ARRAY of ordered steps. Each step:\n   {"order":1,"detail":{"operation":"solution treatment",\n                        "temperature":"900 °C","time":"30 min"},\n    "text":"exact corresponding phrase from process_description"}\n - The detail object may have ANY evidence-supported parameter keys:\n   operation, time, temperature, atmosphere, pressure, reduction,\n   rolling_speed, cooling_rate, etc. Do not invent detail values.\n - EVERY step.text MUST be a contiguous passage from process_description\n   and concatenating step.text in order must reconstruct\n   process_description (whitespace differences are acceptable).\n - If process_description is not supported, use null and [].\n - All property values, elemental percentages and process fields for one\n   record must refer to the SAME actual material/condition.\n\nUse this mandatory complete record template as a SHAPE reference, NOT as\nreal extracted values:\n{TEMPLATE}\n\nALLOWED CLASSIFICATION VOCABULARY:\n{CLASSIFICATIONS}\n\nPAPER DOI: {DOI}\n\nCOMPLETE TABLES (NONE REMOVED, ALL ROWS AND CAPTIONS PRESERVED):\n{TABLES}\n\nSELECTED PRE_DATA ENTRIES: original indices 1 through n-2 (zero-based)\nALL SELECTED PRE_DATA ENTRIES (IN ORDER):\n{PREDATA}\n\nExtract all evidence-supported material/condition rows across these entries\nand the complete tables in THIS SINGLE RESPONSE. Do not invent specimens\nand do not duplicate the same experiment across entries.\n'

FIELDS = ("doi", "material_name", "tensile_strength", "tensile_unit",
          "yield_strength", "yield_unit", "elongation", "elongation_unit",
          *ELEMENTS, "classification", "process_description",
          "process_structured_summary")

_NUM = re.compile(r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?\Z")

def empty_record(doi: str = "") -> dict:
    data = {field: None for field in FIELDS}
    data["doi"] = doi
    data["classification"] = "Unknown"
    data["process_structured_summary"] = []
    return data


def make_output_schema() -> dict:
    props = {}
    for field in FIELDS:
        if field in PROPERTIES or field in ELEMENTS:
            props[field] = {"type": ["number", "null"]}
        elif field == "classification":
            props[field] = {"type": "string", "enum": list(CLASSIFICATIONS)}
        elif field == "process_structured_summary":
            props[field] = {"type": "array", "items": {"type": "object",
                "properties": {"order": {"type": "integer"},
                    "detail": {"type": "object", "additionalProperties":
                               {"type": ["string", "number", "null"]}},
                    "text": {"type": "string"}},
                "required": ["order", "detail", "text"],
                "additionalProperties": False}}
        else:
            props[field] = {"type": ["string", "null"]}
    row = {"type": "object", "properties": props,
           "required": list(FIELDS), "additionalProperties": False}
    return {"type": "object", "properties": {
        "records": {"type": "array", "items": row}},
        "required": ["records"], "additionalProperties": False}


OUTPUT_SCHEMA = make_output_schema()

def doi_from_filename(path: str | Path) -> str:
    stem = Path(path).stem
    match = re.match(r"^(10\.\d{4,9})_(.+)$", stem, re.I)
    return match.group(1) + "/" + match.group(2) if match else stem


def read_paper(path: str | Path) -> tuple[str, list, list]:
    with open(path, "r", encoding="utf-8") as f:
        paper = json.load(f)
    if not isinstance(paper, dict) or not isinstance(paper.get("predata"), list):
        raise ValueError("Paper must contain a predata list")
    if not isinstance(paper.get("tables", []), list):
        raise ValueError("Paper tables must be a list")
    return doi_from_filename(path), paper["predata"], paper.get("tables", [])


def build_messages(doi: str, predata: list, tables: list) -> list[dict]:
    template = json.dumps(empty_record(doi), ensure_ascii=False, separators=(",", ":"))
    user = (USER_INSTRUCTIONS
            .replace("{TEMPLATE}", template)
            .replace("{CLASSIFICATIONS}", ", ".join(CLASSIFICATIONS))
            .replace("{DOI}", doi)
            .replace("{TABLES}", json.dumps(tables, ensure_ascii=False, separators=(",", ":")))
            .replace("{PREDATA}", json.dumps(predata[1:-1], ensure_ascii=False, separators=(",", ":"))))
    return [{"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user}]


def _unique_pairs(pairs: list[tuple]) -> dict:
    result = {}
    for key, val in pairs:
        if key in result:
            raise ValueError("duplicate_json_key:" + key)
        result[key] = val
    return result


def parse_model_json(text: str) -> list[dict]:
    text = re.sub(r"^\s*<think>.*?</think>\s*", "", text.strip(), flags=re.S | re.I)
    obj = json.loads(text, object_pairs_hook=_unique_pairs,
                     parse_constant=lambda x: (_ for _ in ()).throw(ValueError("nonfinite:" + x)))
    if not isinstance(obj, dict) or set(obj) != {"records"} or not isinstance(obj["records"], list):
        raise ValueError("Expected EXACTLY a {'records': list} JSON object")
    return obj["records"]


@dataclass(frozen=True)
class ModelPlan:
    backend: str = "vllm"          # real: "vllm" or "openai_api"
    model_path: str = ""
    gpus: tuple[int, ...] = ()
    batch_size: int = 4
    batch_max_input_bytes: int = 700_000
    batch_sort_window: int = 24
    gpu_memory_utilization: float = 0.90
    # Independent per-model context window. For offline vLLM this is passed
    # to LLM(max_model_len=...); for API this is the expected SERVER limit.
    max_model_len: int = 81920
    # Output token budget for THIS model; effective input budget =
    # max_model_len - max_new_tokens (when counting is enabled/available).
    max_new_tokens: int = 16384
    max_num_seqs: int = 8
    max_num_batched_tokens: int = 8192
    enable_prefix_caching: bool = True
    enable_chunked_prefill: bool = True
    enforce_eager: bool = False
    kv_cache_dtype: str = "auto"
    # Parity with cloud: disable guided JSON for incompatible vLLM installs.
    vllm_guided_json: bool = True
    # Usually leave False for local newer vLLM. Set True only for a legacy V0 fallback.
    legacy_vllm_use_v0: bool = False
    dtype: str = "auto"
    trust_remote_code: bool = False
    use_original_yarn: bool = False   # Qwen only; Gemma3 uses native context
    yarn_original_context: int = 32768
    yarn_factor: float = 2.5
    yarn_rope_theta: float = 1000000.0
    chat_style: str = "default"       # "qwen_no_thinking", "gemma_user_only", "default"
    temperature: float = 0.0
    top_p: float = 0.9
    repetition_penalty: float = 1.08
    max_attempts: int = 2
    show_vllm_progress: bool = False
    fallback_to_single: bool = True
    # OpenAI-compatible Chat Completions: base_url includes /v1.
    # Only used when mode="real", backend="openai_api".
    api_base_url: str = ""
    api_model: str = ""            # served ID / provider model ID; not local path
    api_key_env: str = "OPENAI_API_KEY"  # env VAR name only, never the secret
    api_response_format: str = "json_object" # safest default; schema mode requires provider support
    # Choices: "json_schema" (strict provider support), "json_object" (portable),
    # "guided_json" (legacy vLLM API servers), "none" (prompt-only JSON).
    api_max_concurrency: int = 4
    api_timeout_seconds: float = 300.0
    api_max_retries: int = 3         # request-level retry for network/429/5xx only
    api_retry_base_seconds: float = 2.0
    api_token_parameter: str = "max_tokens"  # or max_completion_tokens
    api_send_sampling: bool = True # set False for reasoning endpoints refusing temperature
    api_extra_body: Optional[dict] = None # e.g. {"chat_template_kwargs":{"enable_thinking":false}}
    api_verify_tls: bool = True
    # "server": trust API provider/server to enforce context (NO local count).
    # "hf_tokenizer": count with an explicitly configured matching tokenizer
    # before sending API requests; tokenizer dependencies required.
    api_context_check: str = "server"
    api_tokenizer_path: str = ""   # HF id/local path, exact model chat template
    api_tokenizer_trust_remote_code: bool = False


MODEL_PLANS: dict[str, ModelPlan] = {
    "qwen3_32b": ModelPlan(
        backend="vllm",
        model_path="/home/talia/Qwen3-32B",
        gpus=(0, 1),
        max_model_len=81920,     # Qwen separately controlled
        max_new_tokens=16384,
        batch_size=8,
        gpu_memory_utilization=0.90,
        chat_style="qwen_no_thinking",
        use_original_yarn=True,
        yarn_original_context=32768,
        yarn_factor=2.5,
        yarn_rope_theta=1000000.0,
    ),
    "gemma3_27b": ModelPlan(
        backend="vllm",
        model_path="/home/talia/Gemma3-27B",
        gpus=(0, 1),
        max_model_len=63840,     # Qwen separately controlled
        max_new_tokens=16384,
        batch_size=8,
        gpu_memory_utilization=0.90,
        chat_style="qwen_no_thinking",
        use_original_yarn=False,
        yarn_original_context=32768,
        yarn_factor=2.5,
        yarn_rope_theta=1000000.0,
    ),
    "gptoss_20b": ModelPlan(
        backend="vllm",
        model_path="/home/talia/chengyiao/models/Qwen3-32B-AWQ/models/Qwen--Qwen3-32B-AWQ/snapshots/master",
        gpus=(0,1),
        max_model_len=65536,     # Qwen separately controlled
        max_new_tokens=16384,
        batch_size=8,
        gpu_memory_utilization=0.90,
        chat_style="qwen_no_thinking",
        use_original_yarn=True,
        yarn_original_context=32768,
        yarn_factor=2,
        yarn_rope_theta=1000000.0,
    ),
}



def engine_is_dead(exc: BaseException) -> bool:
    cur = exc
    visited = set()
    while cur is not None and id(cur) not in visited:
        visited.add(id(cur))
        msg = str(cur).lower()
        if (type(cur).__name__ in ("EngineDeadError", "OutOfMemoryError") or
            "enginecore encountered an issue" in msg or
            "engine core process died" in msg or
            "cuda out of memory" in msg or
            "cuda error: illegal memory access" in msg):
            return True
        cur = cur.__cause__ or cur.__context__
    return False


def messages_for_model(messages: list[dict], chat_style: str) -> list[dict]:
    """Adapt the SAME extraction system/user content for each chat template.
    Google Gemma3-IT has no `system` role: prepend it to a single `user` turn.
    """
    if chat_style != "gemma_user_only":
        return messages
    systems = [m["content"] for m in messages if m.get("role") == "system"]
    non_system = [dict(m) for m in messages if m.get("role") != "system"]
    if not non_system or non_system[0].get("role") != "user":
        raise ValueError("Gemma3 requires a first user message")
    non_system[0]["content"] = "\n\n".join(systems + [non_system[0]["content"]])
    return non_system


class FatalModelEngineError(RuntimeError):
    pass

class VllmRealModel:
    def __init__(self, name: str, plan: ModelPlan):
        if os.environ.get("CUDA_VISIBLE_DEVICES") != ",".join(map(str, plan.gpus)):
            raise RuntimeError(f"{name}: GPU binding was not applied before engine initialization")
        if plan.use_original_yarn:
            os.environ["VLLM_ALLOW_LONG_MAX_MODEL_LEN"] = "1"
        if plan.legacy_vllm_use_v0:
            os.environ["VLLM_USE_V1"] = "0"
        os.environ["TOKENIZERS_PARALLELISM"] = "false"
        from vllm import LLM, SamplingParams
        if plan.vllm_guided_json:
            try:
                from vllm.sampling_params import StructuredOutputsParams
                structured = {
                    "structured_outputs": StructuredOutputsParams(json=OUTPUT_SCHEMA)
                }
                api = "structured_outputs"
            except ImportError:
                from vllm.sampling_params import GuidedDecodingParams
                structured = {
                    "guided_decoding": GuidedDecodingParams(json=OUTPUT_SCHEMA)
                }
                api = "guided_decoding"
        else:
            structured = {}
            api = "prompt_only_json"
        extra = {}
        if plan.use_original_yarn:
            extra["hf_overrides"] = {"rope_parameters":{
                "rope_type":"yarn","factor":plan.yarn_factor,
                "original_max_position_embeddings":plan.yarn_original_context,
                "rope_theta":plan.yarn_rope_theta
            }}
        print(f"[model:start] {name}, gpus={plan.gpus}, tp={len(plan.gpus)}, "
              f"batch={plan.batch_size}, max_model_len={plan.max_model_len}, "
              f"structured={api}", flush=True)
        self.llm = LLM(
            model=plan.model_path,
            tensor_parallel_size=len(plan.gpus),
            gpu_memory_utilization=plan.gpu_memory_utilization,
            max_model_len=plan.max_model_len,
            max_num_seqs=plan.max_num_seqs,
            max_num_batched_tokens=plan.max_num_batched_tokens,
            dtype=plan.dtype,
            trust_remote_code=plan.trust_remote_code,
            enable_prefix_caching=plan.enable_prefix_caching,
            enable_chunked_prefill=plan.enable_chunked_prefill,
            enforce_eager=plan.enforce_eager,
            kv_cache_dtype=plan.kv_cache_dtype,
            seed=0,
            **extra
        )
        self.tokenizer = self.llm.get_tokenizer()
        self.sampling = SamplingParams(
            temperature=plan.temperature, top_p=plan.top_p,
            repetition_penalty=plan.repetition_penalty,
            max_tokens=plan.max_new_tokens,
            **structured
        )
        self.name,self.plan = name,plan

    def prompt_text(self, messages: list[dict]) -> tuple[str,int]:
        messages = messages_for_model(messages, self.plan.chat_style)
        kwargs = {"tokenize": False, "add_generation_prompt": True}
        if self.plan.chat_style == "qwen_no_thinking":
            kwargs["enable_thinking"] = False
        # Each model gets its OWN chat template. No Qwen-specific template
        # options are passed to Gemma or GPT-OSS.
        prompt = self.tokenizer.apply_chat_template(messages, **kwargs)
        token_count = len(self.tokenizer.encode(prompt, add_special_tokens=False))
        if token_count + self.plan.max_new_tokens > self.plan.max_model_len:
            raise ValueError(
                f"context_overflow: input={token_count} output_budget="
                f"{self.plan.max_new_tokens}, model_limit={self.plan.max_model_len}"
            )
        return prompt, token_count

    def _generate(self, ready: list[tuple[str,str,int]], *, size: int) -> list[dict]:
        started = time.perf_counter()
        try:
            output = self.llm.generate(
                [x[1] for x in ready],
                sampling_params=self.sampling,
                use_tqdm=self.plan.show_vllm_progress)
            if len(output) != len(ready):
                raise RuntimeError("vLLM response count mismatch")
        except Exception as exc:
            if engine_is_dead(exc):
                raise FatalModelEngineError(
                    f"{self.name}: EngineCore died during a batch: {traceback.format_exc()}"
                ) from exc
            if len(ready)>1 and self.plan.fallback_to_single:
                print(f"[{self.name}:fallback] isolating {len(ready)} DOI tasks",flush=True)
                results=[]
                for item in ready:
                    results.extend(self._generate([item], size=1))
                return results
            return [{"path":item[0],"error":traceback.format_exc()} for item in ready]
        duration = time.perf_counter()-started
        results=[]
        for (path,prompt,n_tokens),res in zip(ready,output):
            try:
                if not res.outputs:
                    raise ValueError("missing model output")
                choice=res.outputs[0]
                if getattr(choice,"finish_reason",None)=="length":
                    raise ValueError("output_truncated: increase output tokens or segment DOI")
                records=parse_model_json(choice.text)
                generated_tokens=(len(choice.token_ids) if choice.token_ids is not None else None)
                perf={"prompt_tokens":n_tokens,"output_tokens":generated_tokens,
                      "batch_size":size,"batch_seconds":round(duration,3),
                      "model_max_context_tokens":self.plan.max_model_len,
                      "requested_max_new_tokens":self.plan.max_new_tokens,
                      "context_check_mode":"local_tokenizer"}
                results.append({"path":path,"records":records,"perf":perf})
            except Exception:
                results.append({"path":path,"error":traceback.format_exc()})
        return results

    def infer_batch(self, paths: list[str]) -> list[dict]:
        good,finished=[],[]
        for path in paths:
            try:
                doi,predata,tables=read_paper(path)
                messages=build_messages(doi,predata,tables)
                prompt,n=self.prompt_text(messages)
                good.append((path,prompt,n))
            except Exception:
                finished.append({"path":path,"error":traceback.format_exc()})
        if good:
            finished.extend(self._generate(good,size=len(good)))
        return finished


def pack_batches(paths: list[str], plan: ModelPlan) -> list[list[str]]:
    """Local length bucketing avoids one long paper dominating a batch.
    Actual token length is checked exactly before generate(), per model.
    """
    batches=[]
    for i in range(0,len(paths),plan.batch_sort_window):
        window=sorted(paths[i:i+plan.batch_sort_window],key=lambda p:Path(p).stat().st_size)
        pending=[]; current_bytes=0
        for path in window:
            size=Path(path).stat().st_size
            if pending and (len(pending)>=plan.batch_size or
                            current_bytes+size>plan.batch_max_input_bytes):
                batches.append(pending)
                pending=[];current_bytes=0
            pending.append(path)
            current_bytes+=size
        if pending:
            batches.append(pending)
    return batches


def call_openai_compatible_api(client, api_model: str, messages: list[dict],
                               plan: ModelPlan) -> tuple[list,dict]:
    """Chat Completions interface. Responses API is NOT implicitly assumed.
    Explicit format choices avoid silently sending unsupported SDK kwargs.
    """
    kwargs={
        "model": api_model,
        "messages": messages,
        "stream": False,
        plan.api_token_parameter: plan.max_new_tokens,
    }
    if plan.api_send_sampling:
        kwargs.update({
            "temperature":plan.temperature,
            "top_p":plan.top_p,
            # Only send the vLLM-specific penalty if explicitly requested
            # in api_extra_body; upstream OpenAI-compatible vendors differ.
        })
    if plan.api_response_format=="json_schema":
        kwargs["response_format"]={
            "type":"json_schema",
            "json_schema":{
                "name":"metal_extraction_records",
                "strict":True,
                "schema":OUTPUT_SCHEMA
            }
        }
    elif plan.api_response_format=="json_object":
        kwargs["response_format"]={"type":"json_object"}
    extra=dict(plan.api_extra_body or {})
    if plan.api_response_format=="guided_json":
        # Older vLLM OpenAI-compatible servers accept guided_json as an
        # extra request field, not a stock Chat Completions argument.
        extra["guided_json"]=OUTPUT_SCHEMA
    if extra:
        kwargs["extra_body"]=extra
    response=client.chat.completions.create(**kwargs)
    if not response.choices:
        raise ValueError("API returned no chat completion choices")
    choice=response.choices[0]
    reason=getattr(choice,"finish_reason",None)
    if reason in ("length","content_filter"):
        raise ValueError(f"API finish_reason={reason}; response not reliable")
    msg=choice.message
    if getattr(msg,"refusal",None):
        raise ValueError("API returned a model refusal")
    content=getattr(msg,"content",None)
    if not isinstance(content,str) or not content.strip():
        raise ValueError("API returned empty/non-text content")
    records=parse_model_json(content)
    usage=getattr(response,"usage",None)
    perf={
        "prompt_tokens":getattr(usage,"prompt_tokens",None),
        "output_tokens":getattr(usage,"completion_tokens",None),
        "api_model":getattr(response,"model",api_model),
        "api_backend":"openai_api",
        "api_endpoint":plan.api_base_url.rstrip("/"),
    }
    return records,perf



def dumps(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False, separators=(",", ":"), allow_nan=False)


def discover_papers() -> list[tuple[str, str]]:
    root = Path(INPUT_DIR)
    if not root.is_dir():
        raise FileNotFoundError(root)
    files = sorted(root.rglob("*.json") if INPUT_RECURSIVE else root.glob("*.json"))
    output = Path(OUTPUT_DIR).resolve()
    papers, seen = [], {}
    for p in files:
        if not p.is_file() or p.name.startswith(".") or output in p.resolve().parents:
            continue
        doi = doi_from_filename(p)
        if doi in seen:
            raise ValueError(f"DOI collision {doi!r}: {seen[doi]} and {p}")
        seen[doi] = p
        papers.append((doi, str(p)))
        if MAX_PAPERS is not None and len(papers) >= MAX_PAPERS:
            break
    return papers


class JsonlShardWriter:
    """Scan existing model shards once, then append, rotating after 2000 records."""
    def __init__(self, folder: Path, model: str, limit: int):
        if limit <= 0:
            raise ValueError("MAX_RECORDS_PER_JSONL must be positive")
        folder.mkdir(parents=True, exist_ok=True)
        self.folder, self.prefix, self.limit = folder, f"model_{model}", limit
        pattern = re.compile(re.escape(self.prefix) + r"_(\d+)\.jsonl$")
        shards = sorted(
            ((int(match.group(1)), p) for p in folder.glob(f"{self.prefix}_*.jsonl")
             if (match := pattern.fullmatch(p.name))),
            key=lambda item: item[0],
        )
        self.completed = set()
        self.index = 1
        self.count = 0
        self.file = None
        for index, path in shards:
            line_count = 0
            with path.open("r", encoding="utf-8") as handle:
                for lineno, line in enumerate(handle, 1):
                    if not line.strip():
                        raise ValueError(f"Blank line in result shard: {path}:{lineno}")
                    try:
                        record = json.loads(line)
                    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
                        raise ValueError(f"Corrupt JSONL: {path}:{lineno}") from exc
                    if not isinstance(record, dict) or not isinstance(record.get("doi"), str) or not record["doi"].strip():
                        raise ValueError(f"Missing DOI in result: {path}:{lineno}")
                    self.completed.add(record["doi"].strip())
                    line_count += 1
            if line_count > limit:
                raise ValueError(f"Shard exceeds {limit} records: {path}")
            self.index, self.count = index, line_count
        print(f"[resume] model={model} shards={len(shards)} unique_dois={len(self.completed)} "
              f"last_shard={self.index:06d} rows={self.count}", flush=True)

    def _open(self):
        if self.count >= self.limit:
            self.index += 1
            self.count = 0
        if self.file is None:
            path = self.folder / f"{self.prefix}_{self.index:06d}.jsonl"
            self.file = path.open("a", encoding="utf-8")

    def append(self, doi: str, rows: list):
        # Only successfully parsed complete model responses are written.
        if not isinstance(rows, list):
            raise TypeError("Model records must be a list")
        if doi in self.completed:
            return
        # Validate/serialize all rows first; avoid partial writes on bad input.
        serialized = []
        for record in rows:
            if not isinstance(record, dict):
                raise ValueError(f"{doi}: non-object record")
            # Keep the original raw row shape, including all model fields.
            serialized.append(dumps(record))
        for line in serialized:
            self._open()
            self.file.write(line + "\n")
            self.count += 1
            if self.count >= self.limit:
                self.flush()
                self.file.close()
                self.file = None
        self.flush()
        if rows:
            self.completed.add(doi)

    def flush(self):
        if self.file is not None:
            self.file.flush()
            os.fsync(self.file.fileno())

    def close(self):
        if self.file is not None:
            self.flush()
            self.file.close()
            self.file = None


def run_vllm(name: str, plan: ModelPlan, paths: list[str], writer: JsonlShardWriter):
    os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
    os.environ["CUDA_VISIBLE_DEVICES"] = ",".join(map(str, plan.gpus))
    os.environ.setdefault("NCCL_CUMEM_ENABLE", "0")
    model = VllmRealModel(name, plan)
    from tqdm import tqdm

    with tqdm(total=len(paths), desc=name, unit="DOI") as pbar:
        for batch in pack_batches(paths, plan):
            outcomes = model.infer_batch(batch)

            for result in outcomes:
                doi = doi_from_filename(result["path"])
                if "error" in result:
                    print(f"[error] {doi}: {result['error'][-500:]}", flush=True)
                else:
                    writer.append(doi, result["records"])

            pbar.update(len(batch))


def run_api(name: str, plan: ModelPlan, paths: list[str], writer: JsonlShardWriter):
    try:
        from openai import OpenAI
    except ImportError as exc:
        raise RuntimeError("API backend requires: pip install openai") from exc
    key = os.environ.get(plan.api_key_env)
    if not key:
        raise RuntimeError(f"Missing API credential environment variable: {plan.api_key_env}")
    tls_client = None
    if not plan.api_verify_tls:
        import httpx
        tls_client = httpx.Client(verify=False)

    tokenizer = None
    if plan.api_context_check == "hf_tokenizer":
        from transformers import AutoTokenizer
        tokenizer = AutoTokenizer.from_pretrained(
            plan.api_tokenizer_path, trust_remote_code=plan.api_tokenizer_trust_remote_code)
    clients = local()

    def request(path):
        try:
            doi, predata, tables = read_paper(path)
            messages = messages_for_model(build_messages(doi, predata, tables), plan.chat_style)
            if tokenizer is not None:
                kw = {"tokenize": True, "add_generation_prompt": True}
                if plan.chat_style == "qwen_no_thinking":
                    kw["enable_thinking"] = False
                n = len(tokenizer.apply_chat_template(messages, **kw))
                if n + plan.max_new_tokens > plan.max_model_len:
                    raise ValueError(f"context_overflow: input={n} limit={plan.max_model_len}")
        except Exception:
            return {"path": path, "error": traceback.format_exc()}

        if not hasattr(clients, "client"):
            clients.client = OpenAI(
                api_key=key, base_url=plan.api_base_url.rstrip("/"),
                timeout=plan.api_timeout_seconds, max_retries=0,
                **({"http_client": tls_client} if tls_client is not None else {}))
        import random
        for attempt in range(plan.api_max_retries + 1):
            try:
                records, _ = call_openai_compatible_api(
                    clients.client, plan.api_model, messages, plan)
                return {"path": path, "records": records}
            except Exception as exc:
                status = getattr(exc, "status_code", None)
                kind = type(exc).__name__
                transient = (status in (408, 409, 425, 429) or
                             isinstance(status, int) and status >= 500 or
                             kind in ("APIConnectionError", "APITimeoutError",
                                      "ConnectError", "ReadTimeout", "TimeoutException"))
                if status in (401, 403, 404) or kind in (
                    "AuthenticationError", "PermissionDeniedError", "NotFoundError"
                ) or transient and attempt >= plan.api_max_retries:
                    raise RuntimeError(f"{name}: fatal API error: {exc}") from exc
                if not transient:
                    return {"path": path, "error": traceback.format_exc()}
                delay = min(90.0, plan.api_retry_base_seconds * (2 ** attempt))
                time.sleep(delay + random.uniform(0, min(delay, 2)))
        raise AssertionError("unreachable")

    from tqdm import tqdm
    try:
        # Preserve bounded in-flight requests, avoiding a Future for every DOI.
        iterator = iter(paths)
        with ThreadPoolExecutor(max_workers=plan.api_max_concurrency) as pool:
            running = {}
            def refill():
                while len(running) < 2 * plan.api_max_concurrency:
                    p = next(iterator, None)
                    if p is None:
                        break
                    running[pool.submit(request, p)] = p
            refill()
            with tqdm(total=len(paths), desc=name, unit="DOI") as bar:
                while running:
                    done, _ = wait(running, return_when=FIRST_COMPLETED)
                    for future in done:
                        path = running.pop(future)
                        result = future.result()
                        doi = doi_from_filename(path)
                        if "error" in result:
                            print(f"[error] {doi}: {result['error'][-500:]}", flush=True)
                        else:
                            writer.append(doi, result["records"])
                        bar.update(1)
                    refill()
    finally:
        if tls_client is not None:
            tls_client.close()


def main():
    if SELECTED_MODEL not in MODEL_PLANS:
        raise ValueError(f"Unsupported SELECTED_MODEL: {SELECTED_MODEL}")
    plan = MODEL_PLANS[SELECTED_MODEL]
    if plan.backend not in ("vllm", "openai_api"):
        raise ValueError(f"Unsupported backend: {plan.backend}")
    if plan.backend == "vllm" and (not plan.gpus or not Path(plan.model_path).is_dir()):
        raise ValueError(f"Invalid GPU or model path for {SELECTED_MODEL}: {plan.model_path}")
    writer = JsonlShardWriter(
        Path(OUTPUT_DIR), SELECTED_MODEL, MAX_RECORDS_PER_JSONL)
    try:
        papers = discover_papers()
        pending = [path for doi, path in papers if doi not in writer.completed]
        print(f"[queue] input={len(papers)} skipped={len(papers)-len(pending)} "
              f"pending={len(pending)}", flush=True)
        if not pending:
            return
        if plan.backend == "vllm":
            run_vllm(SELECTED_MODEL, plan, pending, writer)
        else:
            run_api(SELECTED_MODEL, plan, pending, writer)
        print("[complete] Existing JSONL retained; new records appended.", flush=True)
    finally:
        writer.close()


if __name__ == "__main__":
    main()
